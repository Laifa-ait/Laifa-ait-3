import React from "react";
import { useTranslation } from "react-i18next";
import { motion, AnimatePresence } from "motion/react";
import { X, Info, LogOut, Globe, Store } from "lucide-react";
import { useMobileMenu } from "../../hooks/useMobileMenu";
import { useMegaMenu } from "../../context/MegaMenuContext";
import { useUI } from "../../context/UIContext";
import { MobileUserCard } from "./MobileUserCard";
import { MobileMenuQuickActions } from "./MobileMenuQuickActions";
import { MobileMenuServices } from "./MobileMenuServices";
import { MobileCategoriesAccordion } from "./MobileCategoriesAccordion";
import { AboutOlmaModal } from "./AboutOlmaModal";

export const MobileMenu: React.FC = () => {
  const { t, i18n } = useTranslation();
  const {
    currentUser,
    userProfile,
    isMobileMenuOpen,
    isAboutOpen,
    setIsAboutOpen,
    aboutText,
    isLoadingAbout,
    fetchAboutText,
    closeMenu,
    handleNav,
    handleLanguageToggle,
    logout,
  } = useMobileMenu();
  const { categoriesData } = useMegaMenu();
  const { setIsCartOpen } = useUI();

  const isRtl = i18n.dir() === "rtl" || i18n.language === "ar";

  return (
    <>
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeMenu}
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-[280]"
            />
            <motion.div
              initial={{ x: isRtl ? "-100%" : "100%" }}
              animate={{ x: 0 }}
              exit={{ x: isRtl ? "-100%" : "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 280 }}
              className={`fixed top-0 bottom-0 ${
                isRtl ? "left-0 rounded-r-3xl" : "right-0 rounded-l-3xl"
              } w-[88vw] max-w-[370px] bg-[#FAFAFC] z-[290] shadow-2xl flex flex-col overflow-hidden border-l border-slate-200/80`}
            >
              {/* Vivid Drawer Header */}
              <div className="flex items-center justify-between px-4.5 pt-4 pb-3.5 relative z-10 bg-white border-b border-slate-200/80">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-orange-500 to-rose-600 text-white flex items-center justify-center shadow-sm shadow-orange-500/25">
                    <Store className="w-4.5 h-4.5 stroke-[2.2]" />
                  </div>
                  <div>
                    <h2 className="text-base font-black text-slate-950 tracking-tight leading-none">
                      OLMA<span className="text-orange-600">RT</span>
                    </h2>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      {t("Navigation & Rayons", "Navigation & Rayons")}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={closeMenu}
                  aria-label="Fermer le menu"
                  className="w-8 h-8 rounded-xl text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 flex items-center justify-center cursor-pointer transition-colors border-none"
                >
                  <X className="w-4.5 h-4.5 stroke-[2.2]" />
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scrollbar-hide relative z-10">
                <MobileUserCard
                  currentUser={currentUser}
                  userProfile={userProfile}
                  onNavigate={handleNav}
                  onClose={closeMenu}
                  onLogout={logout}
                />

                <MobileMenuQuickActions
                  onNavigate={handleNav}
                  onClose={closeMenu}
                  onOpenCart={() => setIsCartOpen(true)}
                />

                <MobileMenuServices onNavigate={handleNav} onClose={closeMenu} />

                <button
                  type="button"
                  onClick={handleLanguageToggle}
                  className="w-full flex items-center justify-between p-3 rounded-2xl bg-white hover:bg-orange-50/40 border border-slate-200/80 shadow-2xs transition-all cursor-pointer text-left rtl:text-right"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-orange-50 flex items-center justify-center text-orange-600 border border-orange-200/60">
                      <Globe className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <span className="text-xs font-bold text-slate-800">
                      {t("Langue d'affichage")}
                    </span>
                  </div>
                  <span className="uppercase text-[11px] font-extrabold text-white bg-gradient-to-r from-orange-500 to-rose-600 px-2.5 py-1 rounded-lg shadow-2xs">
                    {(i18n.language || "FR").split("-")[0]}
                  </span>
                </button>

                <MobileCategoriesAccordion
                  categories={categoriesData}
                  onNavigate={handleNav}
                  onClose={closeMenu}
                />
              </div>

              {/* Drawer Footer */}
              <div className="p-3.5 bg-white border-t border-slate-200/80 shrink-0 space-y-2 z-20 pb-safe">
                <button
                  type="button"
                  onClick={fetchAboutText}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-slate-100 hover:bg-slate-200/80 rounded-xl text-slate-800 font-bold text-xs transition-colors border-none cursor-pointer"
                >
                  <Info className="w-4 h-4 text-orange-600" />
                  <span>{t("À propos d'Olmart")}</span>
                </button>

                {currentUser && (
                  <button
                    type="button"
                    onClick={() => {
                      logout();
                      closeMenu();
                    }}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl transition-all border border-rose-200/90 shadow-2xs cursor-pointer active:scale-98"
                  >
                    <LogOut className="w-4 h-4 stroke-[2.2]" />
                    <span>{t("Se déconnecter", "Se déconnecter")}</span>
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <AboutOlmaModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
        isLoading={isLoadingAbout}
        text={aboutText}
      />
    </>
  );
};
