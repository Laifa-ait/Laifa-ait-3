import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Wrench,
  Building2,
  Store,
  Scale,
  Truck,
  Headphones,
  Car,
  ChevronDown,
  Sparkles,
} from "lucide-react";

interface MobileMenuServicesProps {
  onNavigate: (path: string) => void;
  onClose: () => void;
}

export const MobileMenuServices: React.FC<MobileMenuServicesProps> = ({
  onNavigate,
  onClose,
}) => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);

  const services = [
    {
      id: "auto",
      title: "Olma Auto",
      subtitle: "Motors & Véhicules",
      icon: Car,
      path: "/auto",
      iconBg: "bg-gradient-to-br from-orange-500 to-rose-600 text-white",
      borderColor: "hover:border-orange-300",
    },
    {
      id: "brico",
      title: "Olma Brico",
      subtitle: "Artisans & Travaux",
      icon: Wrench,
      path: "/bricolage",
      iconBg: "bg-gradient-to-br from-amber-500 to-orange-600 text-white",
      borderColor: "hover:border-amber-300",
    },
    {
      id: "immo",
      title: "Olma Immo",
      subtitle: "Location & Vente",
      icon: Building2,
      path: "/immo",
      iconBg: "bg-gradient-to-br from-emerald-500 to-teal-600 text-white",
      borderColor: "hover:border-emerald-300",
    },
    {
      id: "shops",
      title: "Boutiques",
      subtitle: "Marques & Stores",
      icon: Store,
      path: "/shops",
      iconBg: "bg-gradient-to-br from-indigo-600 to-violet-600 text-white",
      borderColor: "hover:border-indigo-300",
    },
    {
      id: "comparator",
      title: "Comparateur",
      subtitle: "Prix & Produits",
      icon: Scale,
      path: "/comparator",
      iconBg: "bg-gradient-to-br from-fuchsia-500 to-rose-600 text-white",
      borderColor: "hover:border-rose-300",
    },
  ];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className="w-full flex items-center justify-between px-4 py-3.5 bg-gradient-to-r from-orange-50/60 via-white to-rose-50/40 hover:bg-orange-50/70 transition-colors cursor-pointer border-none"
      >
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-orange-500" />
          <span className="text-xs font-black uppercase tracking-wider text-slate-900">
            {t("Univers & Services Olmart", "Univers & Services Olmart")}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-extrabold text-orange-600 bg-orange-50 border border-orange-200/70 px-2 py-0.5 rounded-full">
            58 Wilayas
          </span>
          <ChevronDown
            className={`w-4 h-4 text-slate-500 transition-transform duration-200 ${
              isOpen ? "rotate-180 text-orange-600" : ""
            }`}
          />
        </div>
      </button>

      {isOpen && (
        <div className="p-3.5 pt-2 space-y-2.5 border-t border-slate-100">
          <div className="grid grid-cols-2 gap-2">
            {services.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    onNavigate(item.path);
                    onClose();
                  }}
                  className={`flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50/80 hover:bg-white border border-slate-200/80 ${item.borderColor} transition-all text-left rtl:text-right cursor-pointer shadow-2xs group active:scale-98`}
                >
                  <div
                    className={`w-8 h-8 rounded-xl ${item.iconBg} flex items-center justify-center shrink-0 mt-0.5 shadow-2xs`}
                  >
                    <Icon className="w-4 h-4 stroke-[2.2]" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-extrabold text-slate-900 leading-tight group-hover:text-orange-600 transition-colors">
                      {item.title}
                    </p>
                    <p className="text-[10px] text-slate-500 font-medium leading-tight mt-0.5">
                      {item.subtitle}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-slate-100">
            <button
              type="button"
              onClick={() => {
                onNavigate("/shipping-calculator");
                onClose();
              }}
              className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 hover:bg-orange-50/50 text-slate-700 hover:text-orange-600 text-xs font-bold transition-all border border-slate-200/70 cursor-pointer active:scale-98"
            >
              <Truck className="w-3.5 h-3.5 text-orange-500 shrink-0" />
              <span className="truncate">{t("Tarifs Livraison", "Tarifs Livraison")}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onNavigate("/support");
                onClose();
              }}
              className="flex items-center gap-2 p-2 rounded-xl bg-slate-50 hover:bg-orange-50/50 text-slate-700 hover:text-orange-600 text-xs font-bold transition-all border border-slate-200/70 cursor-pointer active:scale-98"
            >
              <Headphones className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span className="truncate">{t("Support & Aide", "Support & Aide")}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
