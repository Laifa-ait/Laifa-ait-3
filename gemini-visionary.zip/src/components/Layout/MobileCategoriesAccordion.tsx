import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { motion, AnimatePresence } from "motion/react";
import { ChevronRight, Box } from "lucide-react";
import { CATEGORY_ICONS } from "../../constants";
import { getCategoryTranslation } from "../../utils/translations";
import { CategoryIcons8Logo } from "../common/CategoryIcons8Logo";

interface CategoryLink {
  name: string;
}

interface CategorySection {
  name: string;
  links?: CategoryLink[];
}

interface CategoryItem {
  id: string;
  name: string;
  sections?: CategorySection[];
}

interface MobileCategoriesAccordionProps {
  categories: CategoryItem[];
  onNavigate: (path: string) => void;
  onClose: () => void;
}

const EXCLUDED = ["electronique", "mode", "supermarche", "artisanat"];

export const MobileCategoriesAccordion: React.FC<MobileCategoriesAccordionProps> = ({
  categories,
  onNavigate,
  onClose,
}) => {
  const { t } = useTranslation();
  const [expandedCat, setExpandedCat] = useState<string | null>(null);
  const [expandedSub, setExpandedSub] = useState<string | null>(null);

  const filteredCategories = categories.filter((cat) => {
    const norm = (cat.name + " " + (cat.id || "")).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    return !EXCLUDED.some((kw) => norm.includes(kw));
  });

  const toggleSub = (subKey: string) => {
    setExpandedSub((prev) => (prev === subKey ? null : subKey));
  };

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between px-1">
        <h4 className="text-[11px] font-black text-slate-500 uppercase tracking-widest">
          {t("Toutes les Catégories", "Toutes les Catégories")}
        </h4>
        <span className="px-2 py-0.5 rounded-full bg-orange-50 border border-orange-200/80 text-[11px] font-black text-orange-600">
          {filteredCategories.length}
        </span>
      </div>

      <div className="flex flex-col space-y-2">
        {filteredCategories.map((cat, i) => {
          const IconComponent = CATEGORY_ICONS[cat.name] || Box;
          const isExpanded = expandedCat === cat.id;
          const hasSubSections = Boolean(cat.sections && cat.sections.length > 0);

          return (
            <div
              key={i}
              className="bg-white rounded-2xl shadow-2xs border border-slate-200/80 overflow-hidden"
            >
              <button
                type="button"
                onClick={() => {
                  if (hasSubSections) {
                    setExpandedCat(isExpanded ? null : cat.id);
                  } else {
                    onNavigate(`/shop?category=${encodeURIComponent(cat.name)}`);
                    onClose();
                  }
                }}
                className="w-full flex items-center justify-between p-3 bg-transparent border-none cursor-pointer hover:bg-orange-50/40 group transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-orange-50/80 group-hover:bg-white transition-colors border border-orange-200/60 shadow-2xs flex items-center justify-center shrink-0">
                    <CategoryIcons8Logo
                      categoryName={cat.name}
                      categoryId={cat.id}
                      className="w-5 h-5 object-contain"
                      fallbackIcon={IconComponent}
                    />
                  </div>
                  <span className="font-bold text-sm text-slate-900 group-hover:text-orange-600 transition-colors truncate">
                    {getCategoryTranslation(cat.name, t)}
                  </span>
                </div>

                <ChevronRight
                  className={`w-4 h-4 shrink-0 transition-transform duration-300 text-slate-400 group-hover:text-orange-500 ${
                    isExpanded ? "rotate-90 text-orange-600" : ""
                  }`}
                />
              </button>

              <AnimatePresence>
                {isExpanded && cat.sections && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden bg-slate-50/80 border-t border-slate-200/60"
                  >
                    <div className="px-3 py-2.5 space-y-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          onNavigate(`/shop?category=${encodeURIComponent(cat.name)}`);
                          onClose();
                        }}
                        className="w-full text-start px-2.5 py-1.5 rounded-xl bg-orange-50/80 hover:bg-orange-100 text-orange-700 text-xs font-extrabold transition-colors cursor-pointer border border-orange-200/60"
                      >
                        Voir tout le rayon {getCategoryTranslation(cat.name, t)} →
                      </button>

                      {cat.sections.map((sec, j) => {
                        const subKey = `${cat.id}-${sec.name}`;
                        const isSubExpanded = expandedSub === subKey;
                        const hasLinks = Array.isArray(sec.links) && sec.links.length > 0;

                        return (
                          <div
                            key={j}
                            className="rounded-xl overflow-hidden bg-white border border-slate-200/60"
                          >
                            <div className="flex items-center justify-between p-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  onNavigate(
                                    `/shop?category=${encodeURIComponent(
                                      cat.name
                                    )}&subcategory=${encodeURIComponent(sec.name)}`
                                  );
                                  onClose();
                                }}
                                className="flex-1 text-start text-xs text-slate-800 font-bold border-none bg-transparent cursor-pointer hover:text-orange-600 transition-colors p-1"
                              >
                                {getCategoryTranslation(sec.name, t)}
                              </button>
                              {hasLinks && (
                                <button
                                  type="button"
                                  onClick={() => toggleSub(subKey)}
                                  className="p-1 text-slate-400 hover:text-orange-600 border-none bg-transparent cursor-pointer"
                                  aria-label={`Ouvrir les rayons de ${sec.name}`}
                                >
                                  <ChevronRight
                                    className={`w-3.5 h-3.5 transition-transform duration-200 ${
                                      isSubExpanded ? "rotate-90 text-orange-600" : ""
                                    }`}
                                  />
                                </button>
                              )}
                            </div>

                            {hasLinks && isSubExpanded && (
                              <div className="px-2.5 pb-2 pt-1 flex flex-wrap gap-1 border-t border-slate-100">
                                {sec.links!.map((link, k) => (
                                  <button
                                    key={k}
                                    type="button"
                                    onClick={() => {
                                      onNavigate(
                                        `/shop?category=${encodeURIComponent(
                                          cat.name
                                        )}&subcategory=${encodeURIComponent(
                                          sec.name
                                        )}&subsubcategory=${encodeURIComponent(link.name)}`
                                      );
                                      onClose();
                                    }}
                                    className="text-[10px] px-2 py-1 rounded-lg bg-orange-50 hover:bg-orange-100 text-orange-800 font-bold transition-colors border border-orange-200/60 cursor-pointer"
                                  >
                                    {getCategoryTranslation(link.name, t)}
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
};
