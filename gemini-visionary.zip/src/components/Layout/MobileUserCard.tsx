import React from "react";
import { useTranslation } from "react-i18next";
import { UserProfile, AuthUser as FirebaseUser } from "../../domains/user/user.types";
import { UserAvatar } from "../ui/UserAvatar";
import { ShieldCheck, Store, LogIn, ChevronRight, User as UserIcon, LogOut } from "lucide-react";

interface MobileUserCardProps {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  onNavigate: (path: string) => void;
  onClose: () => void;
  onLogout?: () => void;
}

export const MobileUserCard: React.FC<MobileUserCardProps> = ({
  currentUser,
  userProfile,
  onNavigate,
  onClose,
  onLogout,
}) => {
  const { t } = useTranslation();

  if (!currentUser) {
    return (
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 rounded-2xl p-4.5 border border-slate-800 shadow-md text-white">
        <div className="flex items-start gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-orange-500 to-rose-600 text-white flex items-center justify-center shrink-0 shadow-sm shadow-orange-500/30">
            <LogIn className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-extrabold text-sm text-white leading-tight">
              {t("Bienvenue sur Olmart")}
            </h4>
            <p className="text-xs text-slate-300 font-normal mt-1 leading-relaxed">
              {t("Connectez-vous pour suivre vos commandes et gérer vos favoris.")}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            onNavigate("/auth");
            onClose();
          }}
          className="w-full mt-3.5 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 active:scale-98 text-white font-bold text-xs transition-all shadow-md shadow-orange-500/25 cursor-pointer border-none"
        >
          <span>{t("Se connecter / S'inscrire")}</span>
          <ChevronRight className="w-4 h-4 rtl:rotate-180 stroke-[2.5]" />
        </button>
      </div>
    );
  }

  const role = userProfile?.role || "buyer";
  const displayName =
    userProfile?.displayName ||
    currentUser.displayName ||
    currentUser.email?.split("@")[0] ||
    "Utilisateur";

  return (
    <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-3.5">
      <div className="flex items-center gap-3.5">
        <UserAvatar
          photoURL={userProfile?.photoURL || currentUser.photoURL}
          displayName={displayName}
          email={currentUser.email}
          size="lg"
          showOnlineBadge={true}
          role={role}
          alt={displayName}
        />

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <h4 className="font-extrabold text-sm text-slate-950 truncate leading-snug">
              {displayName}
            </h4>
            {role === "admin" && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                <ShieldCheck className="w-3 h-3 text-rose-600" />
                <span>{t("Admin", "Admin")}</span>
              </span>
            )}
            {role === "seller" && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-50 text-orange-700 border border-orange-200">
                <Store className="w-3 h-3 text-orange-600" />
                <span>{t("Vendeur", "Vendeur")}</span>
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 truncate mt-0.5 font-normal">
            {currentUser.email}
          </p>
        </div>
      </div>

      <div className="space-y-2 pt-1 border-t border-slate-100">
        <button
          type="button"
          onClick={() => {
            onNavigate("/dashboard/buyer");
            onClose();
          }}
          className="w-full flex items-center justify-between py-2 px-3 rounded-xl bg-slate-50 hover:bg-orange-50/60 text-slate-800 hover:text-orange-600 text-xs font-bold transition-all border border-slate-200/80 active:scale-98 cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-white flex items-center justify-center text-orange-600 border border-slate-200/60 shadow-2xs">
              <UserIcon className="w-3.5 h-3.5 stroke-[2.2]" />
            </div>
            <span>{t("Gérer mon compte Olmart")}</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 rtl:rotate-180" />
        </button>

        {role === "admin" && (
          <button
            type="button"
            onClick={() => {
              onNavigate("/dashboard/admin");
              onClose();
            }}
            className="w-full flex items-center justify-between py-2 px-3 rounded-xl bg-rose-50/80 hover:bg-rose-100/80 text-rose-900 text-xs font-bold transition-all border border-rose-200 active:scale-98 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-rose-600 text-white flex items-center justify-center shadow-2xs">
                <ShieldCheck className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
              <span>{t("Espace Administration")}</span>
            </div>
            <ChevronRight className="w-4 h-4 text-rose-500 rtl:rotate-180" />
          </button>
        )}

        {role === "seller" && (
          <button
            type="button"
            onClick={() => {
              onNavigate("/dashboard/seller");
              onClose();
            }}
            className="w-full flex items-center justify-between py-2 px-3 rounded-xl bg-orange-50/80 hover:bg-orange-100/80 text-orange-950 text-xs font-bold transition-all border border-orange-200 active:scale-98 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-gradient-to-r from-orange-500 to-rose-600 text-white flex items-center justify-center shadow-2xs">
                <Store className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
              <span>{t("Espace Vendeur Pro")}</span>
            </div>
            <ChevronRight className="w-4 h-4 text-orange-500 rtl:rotate-180" />
          </button>
        )}

        {onLogout && (
          <button
            type="button"
            onClick={() => {
              onLogout();
              onClose();
            }}
            className="w-full flex items-center justify-between py-2.5 px-3 rounded-xl bg-rose-50/90 hover:bg-rose-100 text-rose-700 text-xs font-bold transition-all border border-rose-200/90 active:scale-98 cursor-pointer shadow-2xs"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-rose-200/80 text-rose-700 flex items-center justify-center">
                <LogOut className="w-3.5 h-3.5 stroke-[2.2]" />
              </div>
              <span>{t("Se déconnecter", "Se déconnecter")}</span>
            </div>
            <span className="text-[11px] text-rose-600 font-semibold">{t("Déconnexion")}</span>
          </button>
        )}
      </div>
    </div>
  );
};
