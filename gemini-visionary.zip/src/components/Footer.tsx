import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import toast from "react-hot-toast";
import { subscribeToNewsletter } from "../services/newsletterService";
import { QRCodeSVG } from "qrcode.react";
import {
  Store,
  ShoppingBag,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Truck,
  ShieldCheck,
  CreditCard,
  Mail,
  ArrowRight,
} from "lucide-react";
import { BrandIcon } from "./ui/BrandIcon";
import { safeLogger } from "../utils/logger";
import { apiGet } from "../lib/api";

const SOCIALS: Array<{
  name: "facebook" | "instagram" | "tiktok" | "youtube" | "linkedin" | "x" | "whatsapp";
  href: string;
  label: string;
}> = [
  { name: "facebook", href: "https://facebook.com/olmart.dz", label: "Facebook Olmart" },
  { name: "instagram", href: "https://instagram.com/olmart.dz", label: "Instagram Olmart" },
  { name: "tiktok", href: "https://tiktok.com/@olmart.dz", label: "TikTok Olmart" },
  { name: "youtube", href: "https://youtube.com/@olmart", label: "YouTube Olmart" },
  { name: "linkedin", href: "https://linkedin.com/company/olmart", label: "LinkedIn Olmart" },
  { name: "x", href: "https://x.com/olmart_dz", label: "X Olmart" },
  { name: "whatsapp", href: "https://wa.me/213550000000", label: "WhatsApp Olmart" },
];

export const Footer: React.FC<{ isHomepage?: boolean }> = ({ isHomepage = false }) => {
  const { t, i18n } = useTranslation();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const isHome = isHomepage || location.pathname === "/";
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [supportEmail, setSupportEmail] = useState("contact@olmart.dz");
  const isArabic = i18n.language === "ar" || i18n.language?.startsWith("ar");

  useEffect(() => {
    let cancelled = false;
    apiGet<{ supportEmail?: string }>("/api/v1/public/settings")
      .then((data) => {
        if (!cancelled && data?.supportEmail) setSupportEmail(data.supportEmail);
      })
      .catch((error) => {
        if (!cancelled) safeLogger.warn("Fallback support email used", { err: String(error) });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      toast.error(t("Veuillez vous connecter pour vous inscrire à la newsletter."));
      return;
    }
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error(t("invalid_email") || "Veuillez entrer un email valide");
      return;
    }
    setIsSubmitting(true);
    try {
      await subscribeToNewsletter(email);
      toast.success(t("newsletter_success") || "Inscription réussie aux alertes Olmart !");
      setEmail("");
    } catch (error: unknown) {
      safeLogger.error("Erreur newsletter", { err: String(error) });
      toast.error(
        error instanceof Error && error.message === "ALREADY_SUBSCRIBED"
          ? t("already_subscribed") || "Vous êtes déjà inscrit !"
          : t("error_try_later") || "Erreur, veuillez réessayer ultérieurement"
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isHome) return null;

  const buyerLinks = [
    { label: t("footer_all_products", "Catalogue général"), path: "/shop" },
    { label: t("footer_shops_directory", "Boutiques certifiées"), path: "/shops" },
    { label: t("footer_shipping_calc_link", "Frais de livraison"), path: "/shipping-calculator" },
    { label: t("footer_my_orders", "Suivre ma commande"), path: "/buyer/orders" },
    { label: t("footer_returns_guarantees", "Garanties & Retours"), path: "/refund-policy" },
  ];

  const legalLinks = [
    { label: t("footer_support", "Centre d'assistance"), onClick: () => navigate("/support") },
    { label: t("footer_privacy", "Protection des données"), onClick: () => navigate("/privacy-policy") },
    { label: t("footer_terms", "Conditions d'utilisation"), onClick: () => navigate("/terms-of-service") },
    {
      label: t("footer_updates_log", "Nouveautés & Mises à jour"),
      onClick: () => window.dispatchEvent(new CustomEvent("open-olma-updates")),
    },
  ];

  return (
    <footer
      id="olmart-main-footer"
      className={`bg-slate-950 text-slate-300 border-t border-slate-800/80 ${isHomepage ? "pb-24 sm:pb-12" : "pb-12"}`}
    >
      <div className="w-full max-w-[90rem] mx-auto px-4 sm:px-6 md:px-8 pt-12 pb-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-10">
        <div className="lg:col-span-4 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-500 to-rose-600 flex items-center justify-center shrink-0 shadow-md shadow-orange-500/20">
              <Store className="w-5 h-5 text-white stroke-[2.2]" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-black tracking-tight text-white flex items-center gap-0.5 font-sans leading-none">
                {isArabic ? "أولمارت" : "OLMA"}
                {!isArabic && <span className="text-orange-500">RT</span>}
              </span>
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mt-0.5">
                {t("footer_marketplace_subtitle", "Premier Marketplace Algérien")}
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
            {t("footer_marketplace_desc", "La plateforme e-commerce multi-vendeurs de référence en Algérie. Découvrez des milliers de produits certifiés sur les 58 Wilayas.")}
          </p>

          <div className="flex items-center gap-2 pt-0.5">
            {SOCIALS.map((s) => (
              <a
                key={s.name}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.label}
                className="w-8 h-8 rounded-xl bg-slate-900 hover:bg-gradient-to-br hover:from-orange-500 hover:to-rose-600 text-slate-400 hover:text-white border border-slate-800 hover:border-transparent flex items-center justify-center transition-all"
              >
                <BrandIcon name={s.name} size={15} />
              </a>
            ))}
          </div>

          <div className="p-4 rounded-2xl bg-gradient-to-r from-orange-950/50 via-slate-900 to-slate-900 border border-orange-500/25 space-y-2">
            <div className="flex items-center gap-2 text-white font-bold text-xs uppercase tracking-wider">
              <Store className="w-4 h-4 text-orange-400" />
              <span>{t("footer_are_you_merchant", "Vous êtes commerçant ?")}</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-normal">
              {t("footer_open_store_desc", "Rejoignez le réseau Olmart et développez votre activité dans tout le pays.")}
            </p>
            <button
              onClick={() => navigate("/seller-onboarding")}
              className="mt-1 inline-flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer border-none"
            >
              <span>{t("footer_become_seller_btn", "Ouvrir ma boutique")}</span>
              {isArabic ? <ChevronLeft className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <h5 className="text-xs font-bold uppercase tracking-widest text-white flex items-center gap-2 border-b border-slate-800 pb-2">
            <ShoppingBag className="w-4 h-4 text-orange-400" />
            <span>{t("footer_buyers_heading", "Acheteurs")}</span>
          </h5>
          <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
            {buyerLinks.map((item) => (
              <li key={item.path}>
                <button
                  onClick={() => navigate(item.path)}
                  className="hover:text-orange-400 transition-colors bg-transparent border-none p-0 cursor-pointer text-start flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <h5 className="text-xs font-bold uppercase tracking-widest text-white flex items-center gap-2 border-b border-slate-800 pb-2">
            <ShieldCheck className="w-4 h-4 text-orange-400" />
            <span>{t("footer_help_legal_heading", "Aide & Sécurité")}</span>
          </h5>
          <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
            {legalLinks.map((item, idx) => (
              <li key={idx}>
                <button
                  onClick={item.onClick}
                  className="hover:text-orange-400 transition-colors bg-transparent border-none p-0 cursor-pointer text-start flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-4 space-y-4">
          <h5 className="text-xs font-bold uppercase tracking-widest text-white flex items-center gap-2 border-b border-slate-800 pb-2">
            <Sparkles className="w-4 h-4 text-orange-400" />
            <span>{t("footer_offers_app_heading", "Restez Informé")}</span>
          </h5>
          <form className="flex gap-2" onSubmit={handleNewsletterSubmit}>
            <div className="relative flex-1">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t("footer_email_placeholder", "Votre email...")}
                className="w-full bg-slate-900 border border-slate-800 pl-9 pr-3.5 py-2.5 text-xs text-white rounded-xl focus:outline-none focus:border-orange-500 transition-all placeholder:text-slate-500"
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs transition-all border-none shadow-sm cursor-pointer shrink-0 active:scale-95 disabled:opacity-50 flex items-center gap-1"
            >
              <span>{isSubmitting ? "..." : t("footer_subscribe_btn", "OK")}</span>
              {!isSubmitting && <ArrowRight className="w-3.5 h-3.5" />}
            </button>
          </form>

          <div className="p-3 bg-slate-900/80 rounded-2xl border border-slate-800 flex items-center gap-3">
            <div className="w-12 h-12 bg-white p-1 rounded-xl shrink-0 flex items-center justify-center shadow-md">
              <QRCodeSVG value="https://olmart.dz" size={40} level="M" />
            </div>
            <div className="text-[11px] text-slate-400 leading-tight">
              <p className="font-bold text-white text-xs">{t("footer_app_title", "Application Olmart")}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">{t("footer_app_scan", "Scannez pour commander sur mobile")}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full max-w-[90rem] mx-auto px-4 sm:px-6 md:px-8 pt-6 border-t border-slate-800/80 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-400">
        <span className="font-medium text-[11px] text-center md:text-start">
          © {new Date().getFullYear()} {t("footer_copyright", "Olmart Marketplace Algérie.")} {supportEmail && `• ${supportEmail}`}
        </span>
        <div className="flex flex-wrap items-center justify-center gap-2">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-orange-400 font-bold text-[10px]">
            <CreditCard className="w-3 h-3" /> CIB
          </span>
          <span className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-amber-400 font-bold text-[10px]">BaridiMob</span>
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-emerald-400 font-medium text-[10px]">
            <Truck className="w-3 h-3" /> COD (Cash)
          </span>
          <span className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-slate-300 font-medium text-[10px]">Yalidine Express</span>
          <span className="px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-slate-300 font-medium text-[10px]">ZR Express</span>
        </div>
      </div>
    </footer>
  );
};
