import React, { useState, useEffect } from "react";
import {
  Menu,
  User as UserIcon,
  Heart,
  ShoppingBag,
  Globe,
  Store,
  ArrowLeft,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { useShop } from "../context/ShopContext";
import { useUI } from "../context/UIContext";
import { Language } from "../domains/home/homepage.types";
import { AdvancedSearchbar as Searchbar } from "./Search/AdvancedSearchbar";
import { NotificationCenter } from "./NotificationCenter";
import { SuperAppSwitcherModal } from "./common/SuperAppSwitcherModal";
import { UserAvatar } from "./ui/UserAvatar";
import { NavbarTopUtilityBar } from "./NavbarTopUtilityBar";

export interface OlmaLogoProps {
  className?: string;
}

export const OlmaLogo: React.FC<OlmaLogoProps> = ({ className = "w-8 h-8" }) => (
  <svg
    viewBox="92 70 154 175"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    role="img"
    aria-label="Olmart Emblem"
  >
    <g fill="none" stroke="currentColor" strokeLinecap="square" strokeLinejoin="miter">
      <path d="M241 113 L170 74 L98 116 L98 198 L170 239 L241 199" strokeWidth="5.2" />
      <path d="M237 116 L170 80 L104 119 L104 195 L170 233 L237 196" strokeWidth="2.2" />
      <path d="M126 136 L135 123 L198 123 L207 136" strokeWidth="2.8" />
      <path
        d="M126 136 L207 136 L207 140 C207 147 201 152 195 152 C189 152 184 147 184 141 C184 148 179 153 172 153 C165 153 160 148 160 141 C160 148 155 153 148 153 C141 153 136 148 136 141 C136 148 132 152 126 152 C120 152 125 143 126 136 Z"
        strokeWidth="2.8"
      />
      <path d="M132 153 L132 196 L202 196 L202 153" strokeWidth="2.8" />
      <path d="M143 196 L143 162 L161 162 L161 196" strokeWidth="2.8" />
      <circle cx="155" cy="180" r="1.7" fill="currentColor" stroke="none" />
      <rect x="171" y="162" width="21" height="21" strokeWidth="2.8" />
    </g>
  </svg>
);

export const Navbar: React.FC = () => {
  const { currentUser, userProfile } = useAuth();
  const { cart, wishlist } = useCart();
  const { setSearchQuery, setActiveCategory, setIsSaleFilterActive, setActiveTag } = useShop();
  const { setIsCartOpen, setIsWishlistOpen, setIsMobileMenuOpen, setIsAccountMenuOpen } = useUI();
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const isCategoriesPage = location.pathname === "/categories";
  const isProductPage = location.pathname.startsWith("/product/");

  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const [isSwitcherOpen, setIsSwitcherOpen] = useState(false);
  const lang = i18n.language as Language;

  const [isScrolled, setIsScrolled] = useState(false);
  const cartCount = React.useMemo(() => cart.reduce((acc, i) => acc + i.quantity, 0), [cart]);

  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setIsScrolled(window.scrollY > 20);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogoClick = () => {
    navigate("/");
    setSearchQuery("");
    setActiveCategory("Tous");
    setIsSaleFilterActive(false);
    setActiveTag(null);
  };

  return (
    <>
      <NavbarTopUtilityBar
        currentUser={currentUser}
        userProfile={userProfile}
        onOpenSwitcher={() => setIsSwitcherOpen(true)}
      />

      <nav
        className={`${
          isProductPage
            ? "sticky top-0 left-0 right-0 z-40 bg-white/95 text-slate-900 backdrop-blur-xl border-b border-slate-200/80 shadow-xs"
            : `sticky top-0 z-[100] bg-white/95 text-slate-900 backdrop-blur-xl border-b border-slate-200/80 transition-shadow duration-200 ${
                isScrolled ? "shadow-[0_8px_30px_rgba(15,23,42,0.08)]" : "shadow-2xs"
              }`
        } py-2.5 sm:py-3`}
      >
        {isProductPage && (
          <div className="flex lg:hidden items-center justify-between w-full gap-2.5 h-11 px-3 pointer-events-auto">
            <button
              type="button"
              onClick={() => (window.history.length > 2 ? navigate(-1) : navigate("/shop"))}
              className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center shrink-0 cursor-pointer border border-slate-200 shadow-2xs transition-all active:scale-95"
              aria-label="Retour"
            >
              <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
            </button>
            <div className="flex-1 min-w-0">
              <Searchbar variant="transparent" />
            </div>
          </div>
        )}

        <div
          className={`${
            isProductPage ? "hidden lg:flex" : "flex"
          } flex-col lg:flex-row lg:items-center px-3.5 sm:px-6 md:px-8 mx-auto w-full max-w-[90rem] justify-between relative gap-2.5 sm:gap-3 lg:gap-0`}
        >
          <div className="flex items-center justify-between w-full lg:w-auto h-11 sm:h-12">
            {/* Brand Logo */}
            <div className="flex shrink-0 items-center justify-start lg:w-1/4">
              <button
                onClick={handleLogoClick}
                className="flex items-center gap-2.5 shrink-0 select-none cursor-pointer group bg-transparent border-none p-0"
                aria-label="Accueil Olmart"
              >
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-500 via-rose-500 to-rose-600 flex items-center justify-center shrink-0 shadow-md shadow-orange-500/25 group-hover:scale-105 transition-transform">
                  <Store className="w-5 h-5 text-white stroke-[2.2]" />
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-2xl sm:text-[26px] font-sans font-black tracking-tight text-slate-950 leading-none">
                    OLMA<span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-rose-600">RT</span>
                  </span>
                  <span className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-slate-400 mt-0.5">
                    Algeria Market
                  </span>
                </div>
              </button>
            </div>

            {/* Mobile Header Actions */}
            <div className="flex items-center justify-end gap-2 lg:hidden relative shrink-0">
              <button
                type="button"
                onClick={() => setIsWishlistOpen(true)}
                aria-label={t("Favoris") || "Favoris"}
                className="flex items-center justify-center text-slate-700 hover:text-rose-600 bg-slate-100/90 hover:bg-rose-50 transition-all cursor-pointer relative border border-slate-200/80 w-10 h-10 rounded-xl active:scale-95"
              >
                <Heart className="w-4.5 h-4.5 stroke-[2]" />
                {wishlist.length > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-rose-600 text-white flex items-center justify-center text-[9px] font-black shadow-xs border border-white tabular-nums">
                    {wishlist.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setIsCartOpen(true)}
                aria-label={t("Mon Panier") || "Mon Panier"}
                className="flex items-center justify-center text-slate-700 hover:text-orange-600 bg-slate-100/90 hover:bg-orange-50 transition-all cursor-pointer relative border border-slate-200/80 w-10 h-10 rounded-xl active:scale-95"
              >
                <ShoppingBag className="w-4.5 h-4.5 stroke-[2]" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-gradient-to-r from-orange-500 to-rose-600 text-white flex items-center justify-center text-[10px] font-black shadow-xs border border-white tabular-nums">
                    {cartCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(true)}
                aria-label={t("Menu") || "Menu"}
                className="flex items-center justify-center text-white bg-slate-950 hover:bg-slate-800 transition-all cursor-pointer border-none w-10 h-10 rounded-xl shadow-xs active:scale-95"
              >
                <Menu className="w-5 h-5 stroke-[2]" />
              </button>
            </div>
          </div>

          {!isCategoriesPage && (
            <div
              className={`flex-1 flex items-center justify-center w-full px-0 ${
                isProductPage ? "lg:px-12 max-w-2xl" : "lg:px-8 max-w-3xl"
              } order-last lg:order-none gap-2`}
            >
              <div className="w-full">
                <Searchbar variant={isProductPage ? "discreet" : "default"} />
              </div>
            </div>
          )}

          {/* Desktop Right Actions */}
          <div className="hidden lg:flex items-center justify-end gap-2.5 sm:gap-3.5 relative lg:w-1/4 shrink-0">
            <NotificationCenter />

            <div className="relative">
              <button
                onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                aria-expanded={isLangDropdownOpen}
                aria-haspopup="true"
                aria-label="Changer de langue"
                className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-orange-600 hover:bg-orange-50/60 border border-slate-200 transition-all h-10 px-3.5 bg-slate-50 rounded-xl cursor-pointer"
              >
                <Globe className="w-4 h-4 text-orange-500" />
                <span className="uppercase">{lang ? lang.split("-")[0] : "fr"}</span>
              </button>
              {isLangDropdownOpen && (
                <>
                  <div className="fixed inset-0 z-50 cursor-default" onClick={() => setIsLangDropdownOpen(false)} />
                  <div className="absolute top-full right-0 mt-2 bg-white border border-slate-200 shadow-xl z-[60] py-1.5 rounded-2xl min-w-[140px] overflow-hidden">
                    {[
                      { code: "fr", name: "Français" },
                      { code: "ar", name: "العربية" },
                      { code: "en", name: "English" },
                    ].map((l) => (
                      <button
                        key={l.code}
                        onClick={() => {
                          i18n.changeLanguage(l.code);
                          setIsLangDropdownOpen(false);
                        }}
                        className={`w-full text-left rtl:text-right px-4 py-2.5 text-sm font-medium transition-colors bg-transparent border-none cursor-pointer flex items-center justify-between gap-2 hover:bg-orange-50/60 ${
                          lang === l.code ? "text-orange-600 font-bold" : "text-slate-600"
                        }`}
                      >
                        <span>{l.name}</span>
                        {lang === l.code && <span className="w-2 h-2 rounded-full bg-orange-500" />}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            <button
              onClick={() => setIsWishlistOpen(true)}
              className="flex items-center justify-center text-slate-700 hover:text-rose-600 hover:bg-rose-50/70 border border-slate-200 transition-all cursor-pointer relative bg-slate-50 w-10 h-10 rounded-xl"
            >
              <Heart className="w-5 h-5 stroke-[1.8]" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4.5 h-4.5 rounded-full bg-rose-600 text-white flex items-center justify-center text-[9px] font-bold shadow-xs border border-white">
                  {wishlist.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setIsCartOpen(true)}
              aria-label={t("Mon Panier") || "Mon Panier"}
              className="flex items-center justify-center text-slate-700 hover:text-orange-600 hover:bg-orange-50/70 border border-slate-200 transition-all cursor-pointer relative bg-slate-50 w-10 h-10 rounded-xl active:scale-95"
            >
              <ShoppingBag className="w-5 h-5 stroke-[1.8]" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-gradient-to-r from-orange-500 to-rose-600 text-white flex items-center justify-center text-[10px] font-black shadow-xs border border-white tabular-nums">
                  {cartCount}
                </span>
              )}
            </button>

            <button
              onClick={() => (!currentUser ? navigate("/auth", { replace: true }) : setIsAccountMenuOpen(true))}
              aria-haspopup="true"
              aria-label="Compte utilisateur"
              className={`flex items-center justify-center transition-all cursor-pointer w-10 h-10 rounded-xl border ${
                currentUser
                  ? "p-0.5 border-orange-300 hover:ring-2 hover:ring-orange-500/30 bg-white"
                  : "text-slate-700 hover:text-orange-600 hover:bg-orange-50/70 border-slate-200 bg-slate-50"
              }`}
            >
              {currentUser ? (
                <UserAvatar
                  photoURL={userProfile?.photoURL || currentUser.photoURL}
                  displayName={userProfile?.displayName || currentUser.displayName}
                  email={currentUser.email}
                  providerData={currentUser.providerData}
                  size="sm"
                  alt={userProfile?.displayName || "Profil"}
                />
              ) : (
                <UserIcon className="w-5 h-5 stroke-[1.8]" />
              )}
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="flex items-center justify-center text-white bg-slate-950 hover:bg-slate-800 transition-all cursor-pointer border-none w-10 h-10 rounded-xl shrink-0 shadow-xs"
              title={t("menu") || "Menu"}
            >
              <Menu className="w-5 h-5 stroke-[1.8]" />
            </button>
          </div>
        </div>
      </nav>

      <SuperAppSwitcherModal isOpen={isSwitcherOpen} onClose={() => setIsSwitcherOpen(false)} />
    </>
  );
};
