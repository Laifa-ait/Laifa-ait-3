import React, { useState, useEffect } from "react";
import { Sparkles } from "lucide-react";
import { Product } from "../../domains/product/product.types";
import { ProductCard } from "../Product/ProductCard";
import { useTranslation } from "react-i18next";

export const HomeEndlessGrid: React.FC = () => {
  const { t } = useTranslation();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);

  const INITIAL_FETCH_LIMIT = 24;
  const LOAD_MORE_LIMIT = 12;

  useEffect(() => {
    let cancelled = false;
    const fetchInitial = async () => {
      try {
        let docs: Product[] = [];
        try {
          const res = await fetch(`/api/v1/public/home-endless-grid?limit=${INITIAL_FETCH_LIMIT}`);
          if (res.ok) {
            const data = await res.json();
            docs = data.products || [];
          }
        } catch {
          // Proceed to fallback
        }

        if (docs.length === 0) {
          try {
            const fallbackRes = await fetch(`/api/v1/products?limit=${INITIAL_FETCH_LIMIT}`);
            if (fallbackRes.ok) {
              const fallbackData = await fallbackRes.json();
              docs = fallbackData.products || [];
            }
          } catch {
            // Proceed to next
          }
        }

        if (docs.length === 0) {
          try {
            const homeDataRes = await fetch(`/api/v1/public/home-data`);
            if (homeDataRes.ok) {
              const homeData = await homeDataRes.json();
              docs = homeData.featuredProducts || [];
            }
          } catch {
            // Final fallback failed
          }
        }

        if (!cancelled) {
          const validDocs = docs.filter((d) => d && (d.stock === undefined || d.stock > 0));
          setProducts(validDocs);
          setHasMore(docs.length >= INITIAL_FETCH_LIMIT);
        }
      } catch {
        // Silently handle error
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    fetchInitial();
    return () => {
      cancelled = true;
    };
  }, []);

  const loadMoreProducts = async () => {
    if (!hasMore || loadingMore) return;
    setLoadingMore(true);
    try {
      let newDocs: Product[] = [];
      try {
        const res = await fetch(
          `/api/v1/public/home-endless-grid?limit=${LOAD_MORE_LIMIT}&offset=${products.length}`
        );
        if (res.ok) {
          const data = await res.json();
          newDocs = data.products || [];
        }
      } catch {
        // Proceed to fallback
      }

      if (newDocs.length === 0) {
        try {
          const fallbackRes = await fetch(
            `/api/v1/products?limit=${LOAD_MORE_LIMIT}&offset=${products.length}`
          );
          if (fallbackRes.ok) {
            const data = await fallbackRes.json();
            newDocs = data.products || [];
          }
        } catch {
          // Fallback failed
        }
      }

      const validNewDocs = newDocs.filter((d) => d && (d.stock === undefined || d.stock > 0));

      setProducts((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const filteredNew = validNewDocs.filter((p) => !existingIds.has(p.id));
        return [...prev, ...filteredNew];
      });

      setHasMore(newDocs.length >= LOAD_MORE_LIMIT);
    } catch {
      // Silently handle error
    } finally {
      setLoadingMore(false);
    }
  };

  if (loading) {
    return (
      <section className="w-full max-w-[90rem] mx-auto px-4 sm:px-6 md:px-8 mb-12 sm:mb-16">
        <div className="h-7 w-52 bg-slate-200 animate-pulse rounded-xl mb-6" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4 md:gap-5">
          {[...Array(12)].map((_, i) => (
            <div key={i} className="aspect-[4/5] rounded-3xl bg-slate-100 animate-pulse" />
          ))}
        </div>
      </section>
    );
  }

  if (products.length === 0) return null;

  return (
    <section className="w-full max-w-[90rem] mx-auto px-4 sm:px-6 md:px-8 mb-14 sm:mb-20 pt-2">
      <div className="flex items-end justify-between mb-5 sm:mb-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-orange-600">
            <Sparkles className="w-3.5 h-3.5 fill-orange-500 text-orange-500" />
            <span>{t("Arrivages & Découvertes", "Arrivages & Découvertes")}</span>
          </div>
          <h2 className="font-sans text-xl sm:text-2xl md:text-3xl font-black tracking-tight text-slate-950">
            {t("home.endless_grid.title", "Publications récentes")}
          </h2>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-4 md:gap-5">
        {products.map((product, i) => (
          <ProductCard key={product.id} product={product} index={i} />
        ))}
      </div>

      {hasMore && (
        <div className="flex justify-center mt-10 sm:mt-12">
          <button
            type="button"
            onClick={loadMoreProducts}
            disabled={loadingMore}
            className="group relative inline-flex items-center justify-center gap-2.5 px-8 py-3.5 bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white text-xs sm:text-sm font-extrabold tracking-wider uppercase rounded-2xl transition-all duration-200 shadow-lg shadow-orange-500/25 hover:shadow-xl disabled:opacity-60 cursor-pointer border-none active:scale-95"
          >
            {loadingMore ? (
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.3s]" />
                <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.15s]" />
                <div className="w-2 h-2 bg-white rounded-full animate-bounce" />
              </div>
            ) : (
              <span>{t("home.endless_grid.load_more", "Afficher plus d'articles")}</span>
            )}
          </button>
        </div>
      )}
    </section>
  );
};
