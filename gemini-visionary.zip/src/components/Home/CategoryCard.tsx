import React from "react";
import { motion } from "motion/react";
import { useTranslation } from "react-i18next";
import { ArrowUpRight } from "lucide-react";
import { CategoryCardData, getCategoryTheme } from "./categoryThemes";

export type { CategoryCardData };

interface CategoryCardProps {
  card: CategoryCardData;
  index: number;
  scrollVelocity: number;
  onSelect: (key: string) => void;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({
  card,
  index,
  scrollVelocity: _scrollVelocity,
  onSelect,
}) => {
  const { t } = useTranslation();
  const theme = getCategoryTheme(card.key, index);
  const IconComponent = theme.icon;
  const num = (index + 1).toString().padStart(2, "0");

  const displayTitle = card.title ? t(card.title, card.title) : theme.defaultTitle;
  const displaySubtitle = card.subtitle ? t(card.subtitle, card.subtitle) : theme.defaultSubtitle;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3, delay: index * 0.03 }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      onClick={() => onSelect(card.key)}
      className={`relative flex flex-col justify-between w-[200px] sm:w-[235px] md:w-[255px] h-[150px] sm:h-[164px] p-4 sm:p-5 rounded-3xl cursor-pointer shadow-[0_4px_16px_rgba(15,23,42,0.05)] hover:shadow-[0_12px_28px_rgba(15,23,42,0.1)] transition-all duration-300 shrink-0 snap-start group border overflow-hidden select-none touch-pan-x ${theme.bgCard} ${theme.border}`}
    >
      {/* Top Row: Vivid Gradient Icon Box + Index Number */}
      <div className="flex items-start justify-between relative z-10">
        <div
          className={`w-12 h-12 sm:w-13 sm:h-13 rounded-2xl ${theme.bgBlob} ${theme.iconColor} flex items-center justify-center shadow-md group-hover:scale-108 group-hover:rotate-3 transition-transform duration-300`}
        >
          <IconComponent className="w-6 h-6 sm:w-6.5 sm:h-6.5 stroke-[2.1]" />
        </div>

        <div className="flex items-center gap-1.5">
          <span className={`text-[11px] font-mono font-extrabold tracking-wider ${theme.numColor}`}>
            /{num}
          </span>
          <div
            className={`w-7 h-7 rounded-full ${theme.btnBg} text-white flex items-center justify-center shadow-xs transition-transform duration-200 group-hover:scale-110`}
          >
            <ArrowUpRight className="w-3.5 h-3.5 rtl:-scale-x-100 stroke-[2.5]" />
          </div>
        </div>
      </div>

      {/* Bottom Row: Title & Subtitle */}
      <div className="relative z-10 pt-2">
        <h3 className="font-sans font-extrabold text-slate-950 text-sm sm:text-base tracking-tight leading-snug line-clamp-1 group-hover:text-orange-600 transition-colors">
          {displayTitle}
        </h3>
        <p className="font-sans font-medium text-slate-500 text-[11px] sm:text-xs line-clamp-1 mt-0.5">
          {displaySubtitle}
        </p>
      </div>
    </motion.div>
  );
};
