import React from "react";
import { ArrowUpRight, Sparkles } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Banner } from "../../domains/home/homepage.types";
import { getOptimizedImageUrl } from "../../utils/imageUtils";

interface BentoHeroSlideProps {
  banner: Banner;
  index: number;
  totalBanners: number;
  onBannerClick: (banner: Banner) => void;
  lang: string;
}

export const BentoHeroSlide: React.FC<BentoHeroSlideProps> = ({
  banner,
  index,
  totalBanners,
  onBannerClick,
  lang,
}) => {
  const { t } = useTranslation();

  const getTranslatedValue = (b: Banner, key: "title" | "subtitle" | "button_text"): string => {
    if (b.translations?.[lang]?.[key]) {
      return b.translations[lang][key];
    }
    const flatKey = `${key}_${lang}` as keyof Banner;
    const flatVal = b[flatKey];
    if (typeof flatVal === "string" && flatVal) {
      return flatVal;
    }
    const rawVal =
      (key === "title"
        ? b.title || b.name
        : key === "subtitle"
        ? b.subtitle
        : b.button_text || b.ctaText || b.buttonText) || "";
    if (rawVal) {
      return t(rawVal, rawVal);
    }
    return "";
  };

  const title = getTranslatedValue(banner, "title");
  const subtitle = getTranslatedValue(banner, "subtitle");
  const buttonText = getTranslatedValue(banner, "button_text");

  const rawDesktop = banner.desktop_image || banner.desktopImage || banner.imageUrl;
  const desktopImageUrl = getOptimizedImageUrl(rawDesktop, 1400);
  const rawMobile = banner.mobile_image || banner.mobileImageUrl || rawDesktop;
  const mobileImageUrl = getOptimizedImageUrl(rawMobile, 800);

  const hasCustomButtonColor = Boolean(banner.btn_bg_color);
  const hasContent = Boolean(title || subtitle || buttonText);

  return (
    <div
      key={banner.id || index}
      onClick={() => onBannerClick(banner)}
      className="h-full flex-shrink-0 relative overflow-hidden flex items-center cursor-pointer select-none"
      style={{ width: `${100 / totalBanners}%` }}
    >
      <picture className="absolute inset-0 w-full h-full">
        {mobileImageUrl && mobileImageUrl !== desktopImageUrl && (
          <source media="(max-width: 640px)" srcSet={mobileImageUrl} />
        )}
        <img
          loading="eager"
          src={
            desktopImageUrl ||
            "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1200"
          }
          alt={title || "Bannière Olmart"}
          className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-103"
          referrerPolicy="no-referrer"
        />
      </picture>

      {hasContent && (
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/35 to-transparent sm:bg-gradient-to-r sm:from-slate-950/85 sm:via-slate-950/40 sm:to-transparent pointer-events-none" />
      )}

      {hasContent && (
        <div className="absolute inset-x-0 bottom-0 sm:inset-y-0 sm:start-0 p-5 sm:p-8 md:p-11 flex flex-col justify-end sm:justify-center items-start z-10 max-w-[92%] sm:max-w-[70%] md:max-w-[58%]">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-orange-500/90 to-rose-600/90 backdrop-blur-md text-white text-[10px] sm:text-xs font-extrabold uppercase tracking-wider mb-2.5 sm:mb-3 shadow-md">
            <Sparkles className="w-3 h-3 fill-white text-white" />
            <span>{banner.badge || t("Sélection Officielle Olmart", "Sélection Officielle Olmart")}</span>
          </div>

          {title && (
            <h2
              className="text-2xl sm:text-3xl md:text-5xl font-sans font-black tracking-tight mb-1.5 sm:mb-2.5 leading-[1.1] text-start drop-shadow-md"
              style={{ color: banner.title_color || "#FFFFFF" }}
            >
              {title}
            </h2>
          )}

          {subtitle && (
            <p
              className="text-xs sm:text-sm md:text-base font-medium mb-4 sm:mb-6 max-w-lg text-start leading-relaxed drop-shadow-sm text-slate-100/95 line-clamp-2"
              style={{ color: banner.subtitle_color || undefined }}
            >
              {subtitle}
            </p>
          )}

          <div className="pt-0.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onBannerClick(banner);
              }}
              style={
                hasCustomButtonColor
                  ? {
                      backgroundColor: banner.btn_bg_color,
                      color: banner.btn_text_color || "#FFFFFF",
                    }
                  : undefined
              }
              className={`group/btn relative inline-flex items-center gap-2 px-5 sm:px-6 py-2.5 sm:py-3 rounded-2xl font-extrabold text-xs sm:text-sm tracking-tight transition-all duration-200 cursor-pointer border-none shadow-lg active:scale-95 ${
                !hasCustomButtonColor
                  ? "bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white shadow-orange-600/30"
                  : "hover:brightness-105"
              }`}
            >
              <span>{buttonText || t("Découvrir la sélection", "Découvrir la sélection")}</span>
              <ArrowUpRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 stroke-[2.5]" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
