import React from "react";
import {
  Armchair,
  Sparkles,
  Refrigerator,
  CarFront,
  Hammer,
  Dumbbell,
  Baby,
  Palette,
  Gamepad2,
  GraduationCap,
  LucideProps,
} from "lucide-react";

export interface CategoryCardData {
  key: string;
  title: string;
  subtitle?: string;
  image?: string;
}

export interface CategoryTheme {
  bgCard: string;
  bgBlob: string;
  border: string;
  iconColor: string;
  numColor: string;
  btnBg: string;
  icon: React.ComponentType<LucideProps>;
  defaultTitle: string;
  defaultSubtitle: string;
}

const normalize = (val: string): string =>
  val
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, "");

export const THEMES_BY_KEY: Record<string, CategoryTheme> = {
  "Maison & Déco": {
    bgCard: "bg-gradient-to-br from-emerald-50 via-white to-teal-50/80",
    bgBlob: "bg-gradient-to-br from-emerald-500 to-teal-600",
    border: "border-emerald-200/80 hover:border-emerald-400",
    iconColor: "text-white",
    numColor: "text-emerald-600",
    btnBg: "bg-gradient-to-r from-emerald-500 to-teal-600",
    icon: Armchair,
    defaultTitle: "Maison & Décoration",
    defaultSubtitle: "Salons, Mobilier & Linge",
  },
  "Beauté & Santé": {
    bgCard: "bg-gradient-to-br from-fuchsia-50 via-white to-pink-50/80",
    bgBlob: "bg-gradient-to-br from-fuchsia-500 to-pink-600",
    border: "border-fuchsia-200/80 hover:border-fuchsia-400",
    iconColor: "text-white",
    numColor: "text-fuchsia-600",
    btnBg: "bg-gradient-to-r from-fuchsia-500 to-pink-600",
    icon: Sparkles,
    defaultTitle: "Beauté & Soins",
    defaultSubtitle: "Parfums, Cosmétiques & Bien-être",
  },
  "Électroménager": {
    bgCard: "bg-gradient-to-br from-cyan-50 via-white to-sky-50/80",
    bgBlob: "bg-gradient-to-br from-cyan-500 to-blue-600",
    border: "border-cyan-200/80 hover:border-cyan-400",
    iconColor: "text-white",
    numColor: "text-cyan-600",
    btnBg: "bg-gradient-to-r from-cyan-500 to-blue-600",
    icon: Refrigerator,
    defaultTitle: "Électroménager",
    defaultSubtitle: "Froid, Cuisson & Maison",
  },
  "Auto & Moto": {
    bgCard: "bg-gradient-to-br from-orange-50 via-white to-red-50/80",
    bgBlob: "bg-gradient-to-br from-orange-500 to-red-600",
    border: "border-orange-200/80 hover:border-orange-400",
    iconColor: "text-white",
    numColor: "text-orange-600",
    btnBg: "bg-gradient-to-r from-orange-500 to-red-600",
    icon: CarFront,
    defaultTitle: "Auto & Moto",
    defaultSubtitle: "Pièces, Accessoires & Entretien",
  },
  "Bricolage & Outillage": {
    bgCard: "bg-gradient-to-br from-yellow-50 via-white to-amber-50/80",
    bgBlob: "bg-gradient-to-br from-amber-500 to-yellow-600",
    border: "border-amber-200/80 hover:border-amber-400",
    iconColor: "text-white",
    numColor: "text-amber-700",
    btnBg: "bg-gradient-to-r from-amber-500 to-yellow-600",
    icon: Hammer,
    defaultTitle: "Outillage & Travaux",
    defaultSubtitle: "Outillage pro, Jardin & Brico",
  },
  "Sport & Loisirs": {
    bgCard: "bg-gradient-to-br from-lime-50 via-white to-emerald-50/80",
    bgBlob: "bg-gradient-to-br from-lime-500 to-emerald-600",
    border: "border-lime-200/80 hover:border-lime-400",
    iconColor: "text-white",
    numColor: "text-emerald-600",
    btnBg: "bg-gradient-to-r from-lime-500 to-emerald-600",
    icon: Dumbbell,
    defaultTitle: "Sport & Fitness",
    defaultSubtitle: "Musculation, Running & Loisirs",
  },
  "Bébé & Puériculture": {
    bgCard: "bg-gradient-to-br from-sky-50 via-white to-indigo-50/80",
    bgBlob: "bg-gradient-to-br from-sky-500 to-indigo-500",
    border: "border-sky-200/80 hover:border-sky-400",
    iconColor: "text-white",
    numColor: "text-sky-600",
    btnBg: "bg-gradient-to-r from-sky-500 to-indigo-500",
    icon: Baby,
    defaultTitle: "Bébé & Puériculture",
    defaultSubtitle: "Poussettes, Éveil & Confort",
  },
  "Artisanat & Tradition": {
    bgCard: "bg-gradient-to-br from-orange-50 via-white to-rose-50/80",
    bgBlob: "bg-gradient-to-br from-orange-600 to-rose-600",
    border: "border-orange-200/80 hover:border-orange-400",
    iconColor: "text-white",
    numColor: "text-orange-700",
    btnBg: "bg-gradient-to-r from-orange-600 to-rose-600",
    icon: Palette,
    defaultTitle: "Artisanat & Tradition",
    defaultSubtitle: "Céramique, Tissage & Terroir",
  },
  "Jeux & Jouets": {
    bgCard: "bg-gradient-to-br from-violet-50 via-white to-purple-50/80",
    bgBlob: "bg-gradient-to-br from-violet-600 to-purple-600",
    border: "border-violet-200/80 hover:border-violet-400",
    iconColor: "text-white",
    numColor: "text-violet-600",
    btnBg: "bg-gradient-to-r from-violet-600 to-purple-600",
    icon: Gamepad2,
    defaultTitle: "Jeux & Jouets",
    defaultSubtitle: "Consoles, Puzzles & Figurines",
  },
  "Scolaire & Bureau": {
    bgCard: "bg-gradient-to-br from-indigo-50 via-white to-blue-50/80",
    bgBlob: "bg-gradient-to-br from-indigo-600 to-blue-700",
    border: "border-indigo-200/80 hover:border-indigo-400",
    iconColor: "text-white",
    numColor: "text-indigo-600",
    btnBg: "bg-gradient-to-r from-indigo-600 to-blue-700",
    icon: GraduationCap,
    defaultTitle: "Scolaire & Bureau",
    defaultSubtitle: "Papeterie & Organisation",
  },
};

const ALIASES: Record<string, string> = {
  vehiculespieces: "Auto & Moto",
  autoequipement: "Auto & Moto",
  automoto: "Auto & Moto",
  auto: "Auto & Moto",
  bricolagejardin: "Bricolage & Outillage",
  outillagetravaux: "Bricolage & Outillage",
  bricolage: "Bricolage & Outillage",
  maisondecoration: "Maison & Déco",
  maison: "Maison & Déco",
  techperformance: "Électronique",
  tech: "Électronique",
  modeelegance: "Mode",
  epicerieterroir: "Supermarché",
  beautesoins: "Beauté & Santé",
  homeappliances: "Électroménager",
  sportfitness: "Sport & Loisirs",
  bebeenfants: "Bébé & Puériculture",
  artisanat: "Artisanat & Tradition",
  jouets: "Jeux & Jouets",
  scolaire: "Scolaire & Bureau",
};

export const getCategoryTheme = (rawKey: string, indexFallback = 0): CategoryTheme => {
  if (THEMES_BY_KEY[rawKey]) return THEMES_BY_KEY[rawKey];

  const norm = normalize(rawKey);
  const aliasTarget = ALIASES[norm];
  if (aliasTarget && THEMES_BY_KEY[aliasTarget]) return THEMES_BY_KEY[aliasTarget];

  const foundEntry = Object.entries(THEMES_BY_KEY).find(([k]) => {
    const kNorm = normalize(k);
    return kNorm.includes(norm) || norm.includes(kNorm);
  });
  if (foundEntry) return foundEntry[1];

  const themeList = Object.values(THEMES_BY_KEY);
  return themeList[indexFallback % themeList.length];
};
