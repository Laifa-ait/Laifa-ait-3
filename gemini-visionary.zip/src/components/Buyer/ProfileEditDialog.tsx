import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Check, UserCog } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Spinner } from "../ui/Spinner";

export type ProfileEditField = "name" | "nickname" | "birthday" | "gender" | "phone" | "about" | "photo" | null;

interface ProfileEditDialogProps {
  activeModal?: ProfileEditField;
  field?: ProfileEditField;
  name?: string;
  setName?: (v: string) => void;
  nickname?: string;
  setNickname?: (v: string) => void;
  birthDate?: string;
  setBirthDate?: (v: string) => void;
  gender?: string;
  setGender?: (v: string) => void;
  phone?: string;
  setPhone?: (v: string) => void;
  bio?: string;
  setBio?: (v: string) => void;
  saving?: boolean;
  onCancel?: () => void;
  onClose?: () => void;
  onSave?: (data?: Record<string, string>) => void | Promise<void>;
  initialData?: Record<string, string>;
}

export const ProfileEditDialog: React.FC<ProfileEditDialogProps> = ({
  activeModal,
  field,
  name: extName,
  setName: extSetName,
  nickname: extNickname,
  setNickname: extSetNickname,
  birthDate: extBirthDate,
  setBirthDate: extSetBirthDate,
  gender: extGender,
  setGender: extSetGender,
  phone: extPhone,
  setPhone: extSetPhone,
  bio: extBio,
  setBio: extSetBio,
  saving = false,
  onCancel,
  onClose,
  onSave,
  initialData,
}) => {
  const { i18n } = useTranslation();
  const isAr = i18n.language?.startsWith("ar");

  const currentField = activeModal !== undefined ? activeModal : field ?? null;
  const isOpen = currentField !== null && currentField !== "photo";

  const [localPhone, setLocalPhone] = useState(initialData?.phone || "");
  useEffect(() => {
    if (initialData?.phone !== undefined) setLocalPhone(initialData.phone);
  }, [initialData?.phone]);

  const name = extName ?? initialData?.name ?? "";
  const nickname = extNickname ?? initialData?.nickname ?? "";
  const birthDate = extBirthDate ?? initialData?.birthDate ?? "";
  const gender = extGender ?? initialData?.gender ?? "unspecified";
  const phone = extPhone !== undefined ? extPhone : localPhone;
  const bio = extBio ?? initialData?.bio ?? "";

  const handleClose = () => {
    onCancel?.();
    onClose?.();
  };

  const handleSaveClick = () => {
    if (extSetPhone === undefined && currentField === "phone") {
      void onSave?.({ phone: localPhone });
      onClose?.();
      return;
    }
    void onSave?.();
  };

  const titles: Record<string, string> = {
    name: isAr ? "الاسم الكامل" : "Nom complet",
    nickname: isAr ? "اللقب / الاسم المستعار" : "Surnom / Pseudonyme",
    birthday: isAr ? "تاريخ الميلاد" : "Date de naissance",
    gender: isAr ? "الجنس" : "Genre",
    phone: isAr ? "رقم الهاتف" : "Numéro de téléphone",
    about: isAr ? "نبذة واهتمامات" : "Biographie & Intérêts",
  };

  const inputClass =
    "w-full px-4 py-3 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 bg-slate-50/60 focus:bg-white focus:border-orange-500 focus:ring-3 focus:ring-orange-500/15 outline-none transition-all";

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.98 }}
            transition={{ duration: 0.2 }}
            className="bg-white rounded-t-3xl sm:rounded-3xl w-full sm:max-w-md overflow-hidden shadow-2xl border border-slate-200/80"
          >
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-orange-50/60 via-white to-rose-50/60">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-orange-500 to-rose-600 text-white flex items-center justify-center shadow-sm shadow-orange-500/20">
                  <UserCog className="w-4 h-4" />
                </div>
                <h3 className="text-base font-black text-slate-900 tracking-tight">
                  {currentField ? titles[currentField] || "" : ""}
                </h3>
              </div>
              <button
                type="button"
                onClick={handleClose}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors cursor-pointer border-none"
                aria-label="Fermer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {currentField === "name" && (
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
                    {titles.name}
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => extSetName?.(e.target.value)}
                    placeholder={isAr ? "الاسم واللقب" : "Votre prénom et nom"}
                    className={inputClass}
                    autoFocus
                  />
                </div>
              )}

              {currentField === "nickname" && (
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
                    {titles.nickname}
                  </label>
                  <input
                    type="text"
                    value={nickname}
                    onChange={(e) => extSetNickname?.(e.target.value)}
                    placeholder={isAr ? "مثال: أمين_الجزائر" : "Ex: Amine_DZ"}
                    className={inputClass}
                    autoFocus
                  />
                </div>
              )}

              {currentField === "birthday" && (
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
                    {titles.birthday}
                  </label>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => extSetBirthDate?.(e.target.value)}
                    className={inputClass}
                  />
                </div>
              )}

              {currentField === "gender" && (
                <div className="space-y-2">
                  {[
                    { val: "female", label: isAr ? "أنثى" : "Femme" },
                    { val: "male", label: isAr ? "ذكر" : "Homme" },
                    { val: "unspecified", label: isAr ? "أفضل عدم التحديد" : "Ne pas préciser" },
                  ].map((opt) => {
                    const isSelected = gender === opt.val;
                    return (
                      <label
                        key={opt.val}
                        onClick={() => extSetGender?.(opt.val)}
                        className={`flex items-center justify-between p-3.5 rounded-2xl border cursor-pointer transition-all ${
                          isSelected
                            ? "border-orange-500 bg-orange-50/70 text-orange-700 shadow-2xs"
                            : "border-slate-200 hover:bg-slate-50 text-slate-800"
                        }`}
                      >
                        <span className="text-sm font-bold">{opt.label}</span>
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            isSelected ? "border-orange-500 bg-orange-500 text-white" : "border-slate-300"
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                      </label>
                    );
                  })}
                </div>
              )}

              {currentField === "phone" && (
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
                    {isAr ? "رقم الهاتف (الجزائر)" : "Téléphone (Algérie)"}
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => (extSetPhone ? extSetPhone(e.target.value) : setLocalPhone(e.target.value))}
                    placeholder="05XX XX XX XX"
                    className={inputClass}
                    autoFocus
                  />
                </div>
              )}

              {currentField === "about" && (
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
                    {titles.about}
                  </label>
                  <textarea
                    rows={4}
                    value={bio}
                    onChange={(e) => extSetBio?.(e.target.value)}
                    placeholder={isAr ? "شغوف بالتقنية، الأزياء..." : "Passionné de high-tech, mode..."}
                    className={`${inputClass} resize-none`}
                    autoFocus
                  />
                </div>
              )}
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={handleClose}
                className="w-full sm:w-auto px-5 py-2.5 text-xs font-extrabold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-full transition-colors order-2 sm:order-1 cursor-pointer shadow-2xs"
              >
                {isAr ? "إلغاء" : "Annuler"}
              </button>
              <button
                type="button"
                onClick={handleSaveClick}
                disabled={saving}
                className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white text-xs font-extrabold rounded-full shadow-md shadow-orange-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50 order-1 sm:order-2 cursor-pointer border-none active:scale-95"
              >
                {saving && <Spinner size="sm" className="border-white border-t-transparent" />}
                <span>{isAr ? "حفظ التغييرات" : "Enregistrer"}</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
