import React, { useState, useRef } from "react";
import { Camera, Sparkles } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { updateProfile } from "firebase/auth";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { storage } from "../../lib/firebase";
import { apiPut } from "../../lib/api";
import { toast } from "react-hot-toast";
import { useTranslation } from "react-i18next";
import { OptimizedImage } from "../ui/OptimizedImage";
import { ProfilePhotoModal } from "./ProfilePhotoModal";
import { ProfileEditDialog, ProfileEditField } from "./ProfileEditDialog";
import { ProfileCards } from "./ProfileCards";

const DEFAULT_AVATARS = [
  "https://api.dicebear.com/7.x/Notionists/svg?seed=Felix&backgroundColor=ffdfbf",
  "https://api.dicebear.com/7.x/Notionists/svg?seed=Aneka&backgroundColor=c0aede",
  "https://api.dicebear.com/7.x/Notionists/svg?seed=Mimi&backgroundColor=d1d4f9",
  "https://api.dicebear.com/7.x/Notionists/svg?seed=Jack&backgroundColor=b6e3f4",
  "https://api.dicebear.com/7.x/Notionists/svg?seed=Nala&backgroundColor=ffd5dc",
  "https://api.dicebear.com/7.x/Notionists/svg?seed=Leo&backgroundColor=e2f0cb",
];

export const ProfileSettings: React.FC = () => {
  const { i18n } = useTranslation();
  const isAr = i18n.language?.startsWith("ar");
  const { currentUser, userProfile } = useAuth();

  const [name, setName] = useState(
    (typeof userProfile?.name === "string" && userProfile.name) || currentUser?.displayName || ""
  );
  const [nickname, setNickname] = useState(
    (typeof userProfile?.nickname === "string" && userProfile.nickname) || ""
  );
  const [phone, setPhone] = useState(
    (typeof userProfile?.phone === "string" && userProfile.phone) || ""
  );
  const [birthDate, setBirthDate] = useState(
    (typeof userProfile?.birthDate === "string" && userProfile.birthDate) || ""
  );
  const [gender, setGender] = useState(
    (typeof userProfile?.gender === "string" && userProfile.gender) || "unspecified"
  );
  const [bio, setBio] = useState(
    (typeof userProfile?.bio === "string" && userProfile.bio) || ""
  );
  const [photoURL, setPhotoURL] = useState(
    (typeof userProfile?.photoURL === "string" && userProfile.photoURL) ||
      currentUser?.photoURL ||
      DEFAULT_AVATARS[0]
  );

  const [activeModal, setActiveModal] = useState<ProfileEditField>(null);
  const [saving, setSaving] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSaveField = async (fieldsToUpdate: Record<string, string>) => {
    if (!currentUser) return;
    setSaving(true);
    try {
      await apiPut("/api/v1/user/profile", fieldsToUpdate);

      if (fieldsToUpdate.name || fieldsToUpdate.photoURL) {
        await updateProfile(currentUser, {
          displayName: fieldsToUpdate.name || name,
          photoURL: fieldsToUpdate.photoURL || photoURL,
        });
      }

      toast.success(isAr ? "تم تحديث الملف الشخصي" : "Informations mises à jour !");
      setActiveModal(null);
    } catch (error) {
      console.error("Failed to update profile:", error);
      toast.error(isAr ? "حدث خطأ أثناء التحديث" : "Erreur lors de la mise à jour");
    } finally {
      setSaving(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    if (!file.type.startsWith("image/")) {
      toast.error(isAr ? "يرجى اختيار صورة صالحة" : "Veuillez sélectionner une image valide");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error(isAr ? "الحد الأقصى 5 ميجابايت" : "L'image ne doit pas dépasser 5 Mo");
      return;
    }

    setUploadingPhoto(true);
    try {
      const storageRef = ref(storage, `avatars/${currentUser.uid}/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);
      setPhotoURL(downloadURL);
      await handleSaveField({ photoURL: downloadURL });
    } catch (err) {
      console.error("Upload error:", err);
      toast.error(isAr ? "فشل رفع الصورة" : "Échec de l'envoi de la photo");
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleDialogSave = () => {
    switch (activeModal) {
      case "name":
        handleSaveField({ name });
        break;
      case "nickname":
        handleSaveField({ nickname });
        break;
      case "birthday":
        handleSaveField({ birthDate });
        break;
      case "gender":
        handleSaveField({ gender });
        break;
      case "phone":
        handleSaveField({ phone });
        break;
      case "about":
        handleSaveField({ bio });
        break;
    }
  };

  return (
    <div className="max-w-3xl mx-auto pb-16 font-sans text-slate-900">
      {/* Hero Profile Banner */}
      <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 text-white p-6 sm:p-8 mb-6 overflow-hidden shadow-lg border border-slate-800">
        <div className="absolute -top-20 -right-20 w-56 h-56 rounded-full bg-gradient-to-br from-orange-500/30 to-rose-600/20 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-56 h-56 rounded-full bg-amber-500/15 blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center text-center">
          <div className="relative group mb-3.5">
            <div
              onClick={() => setActiveModal("photo")}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-4 border-white/90 shadow-xl cursor-pointer relative bg-slate-800 ring-4 ring-orange-500/30"
            >
              <OptimizedImage
                src={photoURL}
                alt={name || "Profil"}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-slate-950/45 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Camera className="w-7 h-7 text-white" />
              </div>
            </div>
            <button
              type="button"
              onClick={() => setActiveModal("photo")}
              className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-gradient-to-r from-orange-500 to-rose-600 shadow-md border-2 border-slate-900 flex items-center justify-center text-white hover:scale-105 transition-transform cursor-pointer"
              title={isAr ? "تغيير الصورة" : "Modifier la photo"}
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-[11px] font-extrabold text-amber-300 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? "عضو أولمارت المميز" : "Espace Membre Olmart"}</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            {name || (isAr ? "مستخدم أولمارت" : "Utilisateur Olmart")}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-0.5 font-medium">
            {currentUser?.email}
          </p>
        </div>
      </div>

      {/* Main Profile Cards */}
      <ProfileCards
        photoURL={photoURL}
        name={name}
        nickname={nickname}
        birthDate={birthDate}
        gender={gender}
        email={currentUser?.email || null}
        phone={phone}
        bio={bio}
        onOpenField={(field) => setActiveModal(field)}
      />

      {/* Photo Modal */}
      <ProfilePhotoModal
        isOpen={activeModal === "photo"}
        photoURL={photoURL}
        defaultAvatars={DEFAULT_AVATARS}
        uploadingPhoto={uploadingPhoto}
        saving={saving}
        fileInputRef={fileInputRef}
        onSelectPhoto={(av) => setPhotoURL(av)}
        onFileUpload={handleFileUpload}
        onCancel={() => setActiveModal(null)}
        onSave={() => handleSaveField({ photoURL })}
      />

      {/* Field Edit Dialog */}
      <ProfileEditDialog
        activeModal={activeModal}
        name={name}
        setName={setName}
        nickname={nickname}
        setNickname={setNickname}
        birthDate={birthDate}
        setBirthDate={setBirthDate}
        gender={gender}
        setGender={setGender}
        phone={phone}
        setPhone={setPhone}
        bio={bio}
        setBio={setBio}
        saving={saving}
        onCancel={() => setActiveModal(null)}
        onSave={handleDialogSave}
      />
    </div>
  );
};
