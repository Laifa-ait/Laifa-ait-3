import React from "react";
import { ChevronRight, ShieldCheck, MapPin, User, Mail, Phone, Sparkles } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import { OptimizedImage } from "../ui/OptimizedImage";
import { ProfileEditField } from "./ProfileEditDialog";

interface ProfileCardsProps {
  photoURL: string;
  name: string;
  nickname: string;
  birthDate: string;
  gender: string;
  email: string | null;
  phone: string;
  bio: string;
  onOpenField: (field: ProfileEditField) => void;
}

export const ProfileCards: React.FC<ProfileCardsProps> = ({
  photoURL,
  name,
  nickname,
  birthDate,
  gender,
  email,
  phone,
  bio,
  onOpenField,
}) => {
  const { i18n } = useTranslation();
  const isAr = i18n.language?.startsWith("ar");
  const navigate = useNavigate();

  const getGenderLabel = (g: string) => {
    if (g === "female") return isAr ? "أنثى" : "Femme";
    if (g === "male") return isAr ? "ذكر" : "Homme";
    if (g === "custom") return isAr ? "مخصص" : "Personnalisé";
    return isAr ? "غير محدد" : "Non précisé";
  };

  const identityRows: Array<{ field: ProfileEditField; label: string; value: string }> = [
    {
      field: "name",
      label: isAr ? "الاسم الكامل" : "Nom",
      value: name || (isAr ? "غير محدد" : "Non défini"),
    },
    {
      field: "nickname",
      label: isAr ? "الاسم المستعار" : "Surnom / Pseudonyme",
      value: nickname || (isAr ? "غير محدد" : "Non défini"),
    },
    {
      field: "birthday",
      label: isAr ? "تاريخ الميلاد" : "Date de naissance",
      value: birthDate || (isAr ? "غير مدرج" : "Non renseignée"),
    },
    {
      field: "gender",
      label: isAr ? "الجنس" : "Genre",
      value: getGenderLabel(gender),
    },
  ];

  return (
    <div className="space-y-5">
      {/* Informations Générales Card */}
      <div className="bg-white border border-slate-200/80 rounded-3xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-3 bg-gradient-to-r from-orange-50/50 via-white to-rose-50/40">
          <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 border border-orange-200/60 flex items-center justify-center shrink-0">
            <User className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-black text-slate-900 tracking-tight">
              {isAr ? "المعلومات العامة" : "Informations générales"}
            </h3>
            <p className="text-xs text-slate-500">
              {isAr
                ? "بعض المعلومات قد تكون مرئية للمستخدمين الآخرين."
                : "Gérez votre identité personnelle sur Olmart Algérie."}
            </p>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          <button
            type="button"
            onClick={() => onOpenField("photo")}
            className="w-full px-6 py-4 flex items-center justify-between hover:bg-orange-50/30 transition-colors text-left cursor-pointer border-none bg-transparent group"
          >
            <div className="space-y-0.5 pr-4">
              <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider block">
                {isAr ? "صورة الملف الشخصي" : "Photo de profil"}
              </span>
              <p className="text-xs sm:text-sm font-medium text-slate-700">
                {isAr ? "تساعد الصورة في تخصيص حسابك" : "Une photo permet de personnaliser votre compte"}
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <div className="w-11 h-11 rounded-full overflow-hidden border-2 border-orange-200 shadow-xs">
                <OptimizedImage src={photoURL} alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <ChevronRight className="w-4.5 h-4.5 text-slate-400 group-hover:text-orange-500 transition-colors" />
            </div>
          </button>

          {identityRows.map((row) => (
            <button
              key={row.field}
              type="button"
              onClick={() => onOpenField(row.field)}
              className="w-full px-6 py-4 flex items-center justify-between hover:bg-orange-50/30 transition-colors text-left cursor-pointer border-none bg-transparent group"
            >
              <div className="space-y-0.5">
                <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider block">
                  {row.label}
                </span>
                <p className="text-sm font-bold text-slate-900">{row.value}</p>
              </div>
              <ChevronRight className="w-4.5 h-4.5 text-slate-400 group-hover:text-orange-500 transition-colors" />
            </button>
          ))}
        </div>
      </div>

      {/* Coordonnées Card */}
      <div className="bg-white border border-slate-200/80 rounded-3xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-3 bg-gradient-to-r from-emerald-50/50 via-white to-teal-50/30">
          <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200/60 flex items-center justify-center shrink-0">
            <Mail className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-black text-slate-900 tracking-tight">
              {isAr ? "معلومات الاتصال" : "Coordonnées"}
            </h3>
            <p className="text-xs text-slate-500">
              {isAr
                ? "وسائل الاتصال المستخدمة لطلباتك وأمان حسابك."
                : "Moyens de contact utilisés pour vos commandes et la sécurité."}
            </p>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          <div className="px-6 py-4 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider block">
                {isAr ? "البريد الإلكتروني" : "Adresse e-mail"}
              </span>
              <p className="text-sm font-bold text-slate-900">{email}</p>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200/70 text-[11px] text-emerald-700 font-bold">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                {isAr ? "بريد إلكتروني موثق" : "Adresse principale vérifiée"}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onOpenField("phone")}
            className="w-full px-6 py-4 flex items-center justify-between hover:bg-orange-50/30 transition-colors text-left cursor-pointer border-none bg-transparent group"
          >
            <div className="space-y-0.5">
              <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider block">
                {isAr ? "رقم الهاتف" : "Numéro de téléphone"}
              </span>
              <p className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-orange-500" />
                {phone || (isAr ? "أضف رقم هاتف" : "Ajouter un numéro de téléphone")}
              </p>
            </div>
            <ChevronRight className="w-4.5 h-4.5 text-slate-400 group-hover:text-orange-500 transition-colors" />
          </button>
        </div>
      </div>

      {/* Adresses & À Propos Card */}
      <div className="bg-white border border-slate-200/80 rounded-3xl overflow-hidden shadow-xs divide-y divide-slate-100">
        <button
          type="button"
          onClick={() => navigate("/dashboard/buyer?tab=addresses")}
          className="w-full px-6 py-4 flex items-center justify-between hover:bg-orange-50/30 transition-colors text-left cursor-pointer border-none bg-transparent group"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-orange-500 to-rose-600 text-white flex items-center justify-center shadow-sm shadow-orange-500/20 shrink-0">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900">
                {isAr ? "إدارة عناوين التوصيل (58 ولاية)" : "Gérer vos adresses de livraison (58 Wilayas)"}
              </p>
              <p className="text-xs text-slate-500">
                {isAr ? "المنزل، العمل، عناوين ثانوية" : "Domicile, lieu de travail, adresses secondaires"}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4.5 h-4.5 text-slate-400 group-hover:text-orange-500 transition-colors" />
        </button>

        <button
          type="button"
          onClick={() => onOpenField("about")}
          className="w-full px-6 py-4 flex items-center justify-between hover:bg-orange-50/30 transition-colors text-left cursor-pointer border-none bg-transparent group"
        >
          <div className="space-y-0.5">
            <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              {isAr ? "السيرة الذاتية والاهتمامات" : "Biographie & Intérêts"}
            </span>
            <p className="text-sm font-medium text-slate-700 line-clamp-2">
              {bio || (isAr ? "أضف ملاحظة أو فئاتك المفضلة" : "Ajoutez une note ou vos catégories préférées")}
            </p>
          </div>
          <ChevronRight className="w-4.5 h-4.5 text-slate-400 group-hover:text-orange-500 transition-colors" />
        </button>
      </div>
    </div>
  );
};
