import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Upload, Check, Sparkles } from "lucide-react";
import { useTranslation } from "react-i18next";
import { OptimizedImage } from "../ui/OptimizedImage";
import { Spinner } from "../ui/Spinner";

interface ProfilePhotoModalProps {
  isOpen: boolean;
  photoURL: string;
  defaultAvatars: string[];
  uploadingPhoto: boolean;
  saving: boolean;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
  onSelectPhoto: (url: string) => void;
  onFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onCancel: () => void;
  onSave: () => void;
}

export const ProfilePhotoModal: React.FC<ProfilePhotoModalProps> = ({
  isOpen,
  photoURL,
  defaultAvatars,
  uploadingPhoto,
  saving,
  fileInputRef,
  onSelectPhoto,
  onFileUpload,
  onCancel,
  onSave,
}) => {
  const { i18n } = useTranslation();
  const isAr = i18n.language?.startsWith("ar");

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 12 }}
            className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-slate-200/80"
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-orange-50/60 via-white to-rose-50/60">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-orange-500 to-rose-600 text-white flex items-center justify-center shadow-sm shadow-orange-500/20">
                  <Sparkles className="w-4 h-4" />
                </div>
                <h3 className="text-base font-black text-slate-900 tracking-tight">
                  {isAr ? "صورة الملف الشخصي" : "Photo de profil"}
                </h3>
              </div>
              <button
                type="button"
                onClick={onCancel}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors cursor-pointer border-none"
                aria-label="Fermer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-6">
              <p className="text-xs font-medium text-slate-600 text-center leading-relaxed">
                {isAr
                  ? "تساعد الصورة في تخصيص حسابك وتسهيل التعرف عليك داخل مجتمع أولمارت."
                  : "Une photo permet de personnaliser votre compte et d'être facilement reconnu sur Olmart."}
              </p>

              {/* Current Photo Preview */}
              <div className="flex flex-col items-center gap-4">
                <div className="w-28 h-28 rounded-full overflow-hidden border-4 border-orange-100 shadow-lg ring-2 ring-orange-500/30 relative bg-slate-50">
                  <OptimizedImage
                    src={photoURL}
                    alt="Aperçu"
                    className="w-full h-full object-cover"
                  />
                  {uploadingPhoto && (
                    <div className="absolute inset-0 bg-slate-900/50 flex items-center justify-center">
                      <Spinner size="md" className="border-white border-t-transparent" />
                    </div>
                  )}
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={onFileUpload}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingPhoto}
                  className="flex items-center gap-2 px-5 py-2.5 bg-orange-50 hover:bg-orange-100 text-orange-600 border border-orange-200/80 rounded-full text-xs font-black transition-all cursor-pointer active:scale-95"
                >
                  <Upload className="w-4 h-4" />
                  {uploadingPhoto
                    ? isAr
                      ? "جاري الرفع..."
                      : "Téléchargement en cours..."
                    : isAr
                      ? "استيراد صورة من جهازك"
                      : "Importer depuis l'appareil"}
                </button>
              </div>

              {/* Predefined Avatars */}
              <div className="space-y-3 pt-4 border-t border-slate-100">
                <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest block text-center">
                  {isAr ? "أو اختر رمزاً تعبيرياً" : "Ou choisissez une illustration Olmart"}
                </span>
                <div className="grid grid-cols-6 gap-2.5">
                  {defaultAvatars.map((av, idx) => {
                    const isSelected = photoURL === av;
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => onSelectPhoto(av)}
                        className={`relative aspect-square rounded-full overflow-hidden border-2 transition-all cursor-pointer bg-slate-50 p-0 ${
                          isSelected
                            ? "border-orange-500 ring-3 ring-orange-500/25 scale-105 shadow-sm"
                            : "border-slate-200 hover:border-orange-300 opacity-85 hover:opacity-100"
                        }`}
                      >
                        <img
                          src={av}
                          alt={`Avatar ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                        {isSelected && (
                          <div className="absolute inset-0 bg-orange-600/25 flex items-center justify-center">
                            <div className="w-5 h-5 rounded-full bg-orange-500 text-white flex items-center justify-center shadow-xs">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </div>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onCancel}
                className="px-5 py-2.5 text-xs font-extrabold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-full transition-colors cursor-pointer shadow-2xs"
              >
                {isAr ? "إلغاء" : "Annuler"}
              </button>
              <button
                type="button"
                onClick={onSave}
                disabled={saving || uploadingPhoto}
                className="px-6 py-2.5 bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white text-xs font-extrabold rounded-full shadow-md shadow-orange-500/25 transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer border-none active:scale-95"
              >
                {saving && <Spinner size="sm" className="border-white border-t-transparent" />}
                <span>{isAr ? "حفظ الصورة" : "Enregistrer"}</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
