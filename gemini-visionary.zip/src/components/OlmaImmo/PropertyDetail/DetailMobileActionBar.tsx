import React from 'react';
import { useTranslation } from 'react-i18next';
import { MessageSquare, Calendar, Phone } from 'lucide-react';
import { PublicPropertyDTO, PublicOwnerProfile } from '../../../types/realEstate';
import { formatDZD } from '../../../utils/format';

interface DetailMobileActionBarProps {
  property: PublicPropertyDTO;
  ownerProfile: PublicOwnerProfile | null;
  onOpenVisitModal: () => void;
  onOpenBookingModal: () => void;
  onOpenDirectChat: () => void;
}

export const DetailMobileActionBar: React.FC<DetailMobileActionBarProps> = ({
  property,
  ownerProfile: _ownerProfile,
  onOpenVisitModal,
  onOpenBookingModal,
  onOpenDirectChat,
}) => {
  const { t } = useTranslation();
  const isShortTerm = property.listingType === 'rent_short';
  const contactPhone = property.contactPhone;

  return (
    <aside
      aria-label={t('immo_action_bar_aria', 'Actions rapides pour cette annonce')}
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-4 py-3 shadow-[0_-4px_16px_rgba(0,0,0,0.06)] flex items-center justify-between gap-3 safe-bottom"
    >
      <div className="flex flex-col min-w-0">
        <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400">
          {property.listingType === 'sale' ? t('sale_price', 'Prix de vente') : t('rent_price', 'Loyer')}
        </span>
        <div className="flex items-baseline gap-1">
          <span className="text-base font-extrabold text-[#1E3A8A] truncate">
            {formatDZD(property.price)}
          </span>
          {property.pricePeriod && (
            <span className="text-[10px] text-stone-500 font-medium">
              /{property.pricePeriod === 'month' ? t('period_month', 'mois') : property.pricePeriod === 'night' ? t('period_night', 'nuit') : property.pricePeriod}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {contactPhone && (
          <a
            href={`tel:${contactPhone}`}
            aria-label={t('immo_action_call_contact_aria', 'Appeler le contact au {{phone}}', { phone: contactPhone })}
            className="p-2.5 rounded-xl border border-stone-200 text-stone-700 hover:bg-stone-50 transition active:scale-95 min-w-[44px] min-h-[44px] flex items-center justify-center cursor-pointer"
          >
            <Phone className="w-4 h-4 text-[#1E3A8A]" />
          </a>
        )}

        <button
          type="button"
          onClick={onOpenDirectChat}
          aria-label={t('immo_action_msg_owner_aria', 'Envoyer un message au propriétaire')}
          className="p-2.5 rounded-xl border border-stone-200 text-stone-700 hover:bg-stone-50 transition active:scale-95 min-w-[44px] min-h-[44px] flex items-center justify-center cursor-pointer"
        >
          <MessageSquare className="w-4 h-4 text-[#1E3A8A]" />
        </button>

        {isShortTerm ? (
          <button
            type="button"
            onClick={onOpenBookingModal}
            className="px-4 py-2.5 bg-[#F59E0B] hover:bg-amber-600 text-slate-900 rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 active:scale-95 cursor-pointer min-h-[44px]"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>{t('immo_action_book', 'Réserver')}</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={onOpenVisitModal}
            className="px-4 py-2.5 bg-[#1E3A8A] hover:bg-blue-900 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 active:scale-95 cursor-pointer min-h-[44px]"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>{t('immo_action_plan_visit', 'Planifier visite')}</span>
          </button>
        )}
      </div>
    </aside>
  );
};
