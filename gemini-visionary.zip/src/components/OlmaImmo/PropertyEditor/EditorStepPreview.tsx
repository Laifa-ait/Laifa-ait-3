import React from 'react';
import { Eye, Phone, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { PropertyType, ListingType, GeoPointLocation, LegalPaperType } from '../../../types/realEstate';
import {
  PropertyMedia,
  PropertyBadge,
  PropertyPrice,
  PropertyLocation,
  PropertyMeta,
  OlmaPill,
} from '../primitives';

interface EditorStepPreviewProps {
  title: string;
  description: string;
  listingType: ListingType;
  propertyType: PropertyType;
  legalPaperType?: LegalPaperType;
  location: GeoPointLocation;
  price: number;
  pricePeriod: 'night' | 'month' | 'total';
  rooms: number;
  areaSquareMeters: number;
  bathrooms: number;
  images: string[];
  features: string[];
  contactPhone: string;
}

export const EditorStepPreview: React.FC<EditorStepPreviewProps> = ({
  title,
  description,
  listingType,
  propertyType,
  legalPaperType,
  location,
  price,
  pricePeriod,
  rooms,
  areaSquareMeters,
  bathrooms,
  images,
  features,
  contactPhone,
}) => {
  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
      <div>
        <h3 className="text-xl font-bold text-[#1E3A8A] font-['Playfair_Display',serif] flex items-center gap-2">
          <Eye className="w-5 h-5 text-[#1E3A8A]" aria-hidden="true" />
          <span>Aperçu avant publication</span>
        </h3>
        <p className="text-xs text-slate-500 mt-0.5">
          Vérifiez l'ensemble des informations de votre annonce avant mise en ligne.
        </p>
      </div>

      {/* Publication Status Banner */}
      <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-[#1E3A8A] shrink-0 mt-0.5" aria-hidden="true" />
        <div className="text-xs text-[#1E3A8A] space-y-0.5">
          <p className="font-bold">Publication immédiate avec statut actif</p>
          <p className="text-slate-600 leading-relaxed">
            Votre annonce sera mise en ligne instantanément. Notre équipe modèrera vos pièces justificatives pour vous attribuer le badge de confiance <strong>Dossier Vérifié</strong>.
          </p>
        </div>
      </div>

      <div className="bg-slate-50 rounded-3xl border border-slate-200 overflow-hidden">
        {/* Photo Header */}
        <PropertyMedia
          src={images[0]}
          alt={title || 'Aperçu annonce'}
          aspectRatio="21/9"
          topBadges={
            <>
              <PropertyBadge type="listingType" value={listingType} size="sm" />
              <OlmaPill variant="highlight" size="sm">
                {propertyType}
              </OlmaPill>
              {legalPaperType && (
                <PropertyBadge type="legalPaper" value={legalPaperType} size="sm" />
              )}
            </>
          }
          bottomOverlay={
            <div className="inline-flex items-center px-4 py-2 rounded-2xl bg-white/95 backdrop-blur-md text-[#1E3A8A] shadow-md border border-white/50">
              <PropertyPrice
                price={price}
                period={pricePeriod}
                listingType={listingType}
                size="md"
                variant="default"
              />
            </div>
          }
        />

        {/* Info Body */}
        <div className="p-6 space-y-4">
          <div>
            <h4 className="text-xl font-bold text-[#1E3A8A] font-['Playfair_Display',serif]">
              {title || 'Titre de votre annonce'}
            </h4>
            <PropertyLocation
              commune={location.commune}
              wilaya={location.wilaya}
              size="sm"
              variant="muted"
              className="mt-1"
            />
          </div>

          {/* Specs */}
          <PropertyMeta
            rooms={rooms}
            areaSquareMeters={areaSquareMeters}
            bathrooms={bathrooms}
            layout="bar"
            size="md"
          />

          <p className="text-xs text-slate-700 whitespace-pre-line leading-relaxed">
            {description || 'Aucune description rédigée.'}
          </p>

          {contactPhone && (
            <div className="flex items-center gap-1.5 text-xs text-[#1E3A8A] font-semibold pt-1">
              <Phone className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Contact : {contactPhone}</span>
            </div>
          )}

          {features.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-2">
              {features.map((f, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 bg-white border border-slate-200 text-[#1E3A8A] rounded-lg text-[11px] font-semibold flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3 h-3 text-[#1E3A8A]" />
                  <span>{f}</span>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

