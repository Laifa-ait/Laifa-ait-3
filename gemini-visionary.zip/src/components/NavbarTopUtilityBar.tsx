import React from "react";
import {
  ShoppingBag,
  Wrench,
  Building2,
  Store,
  Car,
  Scale,
  Truck,
  Headphones,
  LayoutGrid,
  Sparkles,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AuthUser as FirebaseUser, UserProfile } from "../domains/user/user.types";

interface NavbarTopUtilityBarProps {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  onOpenSwitcher: () => void;
}

export const NavbarTopUtilityBar: React.FC<NavbarTopUtilityBarProps> = ({
  currentUser,
  userProfile,
  onOpenSwitcher,
}) => {
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();

  const universes = [
    {
      path: "/shop",
      isActive: location.pathname === "/" || location.pathname.startsWith("/shop"),
      label: t("Marketplace", "Marketplace"),
      icon: ShoppingBag,
      activeClass: "bg-gradient-to-r from-orange-500 to-rose-600 text-white shadow-sm",
    },
    {
      path: "/bricolage",
      isActive: location.pathname.startsWith("/bricolage"),
      label: t("Olma Bricolage", "Olma Bricolage"),
      badge: t("Artisans", "Artisans"),
      icon: Wrench,
      activeClass: "bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-sm",
    },
    {
      path: "/auto",
      isActive: location.pathname.startsWith("/auto"),
      label: t("Olma Auto", "Olma Auto"),
      icon: Car,
      activeClass: "bg-gradient-to-r from-rose-600 to-orange-500 text-white shadow-sm",
    },
    {
      path: "/immo",
      isActive: location.pathname.startsWith("/immo"),
      label: t("Olma Immo", "Olma Immo"),
      icon: Building2,
      activeClass: "bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-sm",
    },
    {
      path: "/shops",
      isActive: location.pathname.startsWith("/shops"),
      label: t("Boutiques", "Boutiques"),
      icon: Store,
      activeClass: "bg-gradient-to-r from-indigo-500 to-violet-600 text-white shadow-sm",
    },
    {
      path: "/comparator",
      isActive: location.pathname.startsWith("/comparator"),
      label: t("Comparateur", "Comparateur"),
      icon: Scale,
      activeClass: "bg-gradient-to-r from-fuchsia-500 to-rose-600 text-white shadow-sm",
    },
  ];

  return (
    <div
      id="olmart-top-utility-bar"
      className="bg-slate-950 text-slate-200 text-xs font-medium px-3 sm:px-6 lg:px-8 py-2 border-b border-slate-800/80 relative z-[101]"
    >
      <div className="flex items-center mx-auto w-full max-w-[90rem] justify-between gap-3">
        {/* Scrollable Universe Hub (Mobile + Desktop) */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar whitespace-nowrap py-0.5">
          <button
            type="button"
            onClick={onOpenSwitcher}
            className="px-3 py-1 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 bg-slate-900 text-white border border-slate-700/80 hover:border-orange-500/60 hover:bg-slate-800 cursor-pointer group shrink-0"
            title={t("Ouvrir le commutateur d'univers Olmart Super-App", "Ouvrir le commutateur d'univers Olmart Super-App")}
          >
            <LayoutGrid className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform text-orange-400" />
            <span>{t("Univers", "Univers")}</span>
          </button>

          {universes.map((u) => {
            const Icon = u.icon;
            return (
              <Link
                key={u.path}
                to={u.path}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-all flex items-center gap-1.5 shrink-0 ${
                  u.isActive
                    ? `${u.activeClass} font-bold`
                    : "text-slate-300 hover:text-white hover:bg-slate-800/90"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{u.label}</span>
                {u.badge && (
                  <span className="text-[9px] uppercase px-1.5 py-0.2 rounded-full bg-amber-400/20 text-amber-300 font-extrabold border border-amber-400/30">
                    {u.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </div>

        {/* Desktop Quick Tools & Seller CTA */}
        <div className="hidden xl:flex items-center gap-4 text-xs font-medium shrink-0">
          <Link
            to="/shipping-calculator"
            className="text-slate-300 hover:text-orange-400 transition-colors flex items-center gap-1.5"
          >
            <Truck className="w-3.5 h-3.5 text-orange-400" />
            <span>{t("shipping_calc") || "Livraison 58 Wilayas"}</span>
          </Link>

          <span className="text-slate-800">|</span>

          <Link
            to="/support"
            className="text-slate-300 hover:text-orange-400 transition-colors flex items-center gap-1.5"
          >
            <Headphones className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t("support") || "Aide & Support"}</span>
          </Link>

          <button
            type="button"
            onClick={() => {
              if (currentUser && userProfile?.role === "seller") {
                navigate("/dashboard/seller");
              } else if (currentUser) {
                navigate("/dashboard/buyer");
              } else {
                navigate("/auth?role=seller");
              }
            }}
            className="px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 font-black transition-all shadow-sm cursor-pointer border-none uppercase tracking-wider text-[11px] flex items-center gap-1"
          >
            <Sparkles className="w-3 h-3 fill-slate-950" />
            <span>{t("sell_on_olma")}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
