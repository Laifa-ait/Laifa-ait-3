import React from "react";
import { Ruler } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Product } from "../../../domains/product/product.types";

export interface ProductVariantsStudsProps {
  product: Product;
  selectedSize: string | null;
  onSelectSize: (size: string) => void;
  selectedColor: string | null;
  onSelectColor: (color: string) => void;
  isColorOutOfStock?: (color: string) => boolean;
  isSizeOutOfStock?: (size: string) => boolean;
  variantImages?: Record<string, string>;
  onSelectVariantImage?: (url: string) => void;
  onOpenSizeGuide: () => void;
}

const COLOR_MAP: Record<string, string> = {
  noir: "#18181b",
  black: "#18181b",
  blanc: "#ffffff",
  white: "#ffffff",
  rouge: "#ef4444",
  red: "#ef4444",
  bleu: "#3b82f6",
  blue: "#3b82f6",
  vert: "#10b981",
  green: "#10b981",
  jaune: "#eab308",
  yellow: "#eab308",
  gris: "#6b7280",
  gray: "#6b7280",
  grey: "#6b7280",
  rose: "#ec4899",
  pink: "#ec4899",
  marron: "#78350f",
  brown: "#78350f",
  beige: "#f5f5dc",
  or: "#d4af37",
  gold: "#d4af37",
  argent: "#c0c0c0",
  silver: "#c0c0c0",
  violet: "#8b5cf6",
  purple: "#8b5cf6",
  orange: "#f97316",
};

export const ProductVariantsStuds: React.FC<ProductVariantsStudsProps> = ({
  product,
  selectedSize,
  onSelectSize,
  selectedColor,
  onSelectColor,
  isColorOutOfStock,
  isSizeOutOfStock,
  variantImages,
  onSelectVariantImage,
  onOpenSizeGuide,
}) => {
  const { t, i18n } = useTranslation();
  const isAr = i18n.language?.startsWith("ar");

  const tr = (key: string, frFallback: string, arFallback: string) => {
    const val = t(key, isAr ? arFallback : frFallback);
    if (!val || val === key) {
      return isAr ? arFallback : frFallback;
    }
    return val;
  };

  const hasColors = Boolean(product.colors && product.colors.length > 0);
  const hasSizes = Boolean(product.sizes && product.sizes.length > 0);

  if (!hasColors && !hasSizes) return null;

  return (
    <div className="space-y-5 py-4 border-y border-slate-200/80">
      {/* Colors Selector */}
      {hasColors && (
        <div className="space-y-2.5">
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
              {tr("product.details.nuances", "Couleurs disponibles", "الألوان المتاحة")}
            </span>
            {selectedColor && (
              <span className="text-xs font-extrabold text-orange-600 bg-orange-50 px-2.5 py-0.5 rounded-full border border-orange-200/60">
                {selectedColor}
              </span>
            )}
          </div>
          <div className="flex flex-wrap gap-2.5">
            {product.colors!.map((color) => {
              const isSelected = selectedColor === color;
              const outOfStock = isColorOutOfStock ? isColorOutOfStock(color) : false;
              const vImg = variantImages?.[color];
              const hexColor = COLOR_MAP[color.toLowerCase().trim()];

              return (
                <button
                  key={color}
                  type="button"
                  disabled={outOfStock}
                  onClick={() => {
                    onSelectColor(color);
                    if (vImg && onSelectVariantImage) {
                      onSelectVariantImage(vImg);
                    }
                  }}
                  aria-label={`Couleur : ${color}`}
                  aria-pressed={isSelected}
                  className={`group relative flex items-center gap-2 px-3.5 py-2 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                    outOfStock
                      ? "bg-slate-100 text-slate-400 border border-slate-200 opacity-50 line-through cursor-not-allowed"
                      : isSelected
                        ? "bg-slate-900 text-white shadow-md ring-2 ring-orange-500 ring-offset-1"
                        : "bg-white text-slate-700 border border-slate-200 hover:border-orange-300 hover:bg-orange-50/30"
                  }`}
                >
                  {vImg ? (
                    <img
                      loading="lazy"
                      src={vImg}
                      alt={color}
                      className="w-5 h-5 rounded-full object-cover border border-white/20"
                    />
                  ) : hexColor ? (
                    <span
                      className="w-4 h-4 rounded-full border border-slate-300 shadow-2xs shrink-0"
                      style={{ backgroundColor: hexColor }}
                    />
                  ) : null}
                  <span>{color}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Sizes Selector */}
      {hasSizes && (
        <div className="space-y-2.5">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">
                {tr("product.details.sizes", "Tailles & Pointures", "المقاسات")}
              </span>
              {selectedSize && (
                <span className="text-xs font-extrabold text-slate-900">
                  — {selectedSize}
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={onOpenSizeGuide}
              className="text-xs font-extrabold text-orange-600 hover:text-orange-700 flex items-center gap-1 transition-colors cursor-pointer bg-orange-50 px-2.5 py-1 rounded-full border border-orange-200/70"
            >
              <Ruler className="w-3.5 h-3.5" />
              <span>{tr("product.details.size_guide", "Guide des tailles", "دليل المقاسات")}</span>
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {product.sizes!.map((size) => {
              const isSelected = selectedSize === size;
              const outOfStock = isSizeOutOfStock ? isSizeOutOfStock(size) : false;
              return (
                <button
                  key={size}
                  type="button"
                  disabled={outOfStock}
                  onClick={() => onSelectSize(size)}
                  aria-label={`Taille : ${size}`}
                  aria-pressed={isSelected}
                  className={`min-w-[3.25rem] h-11 px-3.5 rounded-xl font-black text-xs transition-all flex items-center justify-center cursor-pointer ${
                    outOfStock
                      ? "bg-slate-100 text-slate-400 border border-slate-200 opacity-50 line-through cursor-not-allowed"
                      : isSelected
                        ? "bg-gradient-to-r from-orange-500 to-rose-600 text-white shadow-md shadow-orange-500/25 scale-102 border-none"
                        : "bg-white text-slate-800 border border-slate-200 hover:border-orange-400 hover:text-orange-600"
                  }`}
                >
                  {size}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
