import React, { useState } from "react";
import {
  ShoppingBag,
  Heart,
  Share2,
  ShieldCheck,
  Truck,
  Banknote,
  RotateCcw,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { Product } from "../../../domains/product/product.types";
import { formatPrice } from "../../../utils/format";

export interface ProductBuyBoxProps {
  product: Product;
  isCurrentSelectionOutOfStock?: boolean;
  onAddToCart: (quantity?: number) => void;
  onToggleWishlist: () => void;
  wishlist?: string[];
  isLiked?: boolean;
  onShare: () => void;
  isSticky?: boolean;
  quantity?: number;
  onChangeQuantity?: (q: number) => void;
  onBuyNow?: () => void;
}

export const ProductBuyBox: React.FC<ProductBuyBoxProps> = ({
  product,
  isCurrentSelectionOutOfStock = false,
  onAddToCart,
  onToggleWishlist,
  wishlist = [],
  isLiked: isLikedProp,
  onShare,
  isSticky = false,
  quantity: externalQuantity,
  onChangeQuantity,
}) => {
  const { t, i18n } = useTranslation();
  const isAr = i18n.language?.startsWith("ar");
  const [internalQty, setInternalQty] = useState(1);

  const quantity = externalQuantity ?? internalQty;
  const setQuantity = onChangeQuantity ?? setInternalQty;
  const isLiked = isLikedProp ?? wishlist.includes(product.id);
  const isOutOfStock = isCurrentSelectionOutOfStock || product.stock <= 0;
  const effectivePrice = product.promoPrice || product.price || 0;

  const tr = (key: string, frFallback: string, arFallback: string) => {
    const val = t(key, isAr ? arFallback : frFallback);
    if (!val || val === key) {
      return isAr ? arFallback : frFallback;
    }
    return val;
  };

  return (
    <div className="space-y-5 pt-2">
      {/* Quantity & Stock Indicator Row */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-xs font-black text-slate-600 uppercase tracking-wider">
            {isAr ? "الكمية" : "Quantité"}
          </span>
          <div className="flex items-center border border-slate-200 rounded-xl bg-white h-11 px-1 shadow-2xs">
            <button
              type="button"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              disabled={isOutOfStock || quantity <= 1}
              className="w-9 h-9 rounded-lg flex items-center justify-center font-black text-base text-slate-600 hover:bg-slate-100 disabled:opacity-30 transition-colors cursor-pointer border-none bg-transparent"
              aria-label="Diminuer la quantité"
            >
              -
            </button>
            <span className="w-9 text-center font-black text-sm text-slate-900 tabular-nums">
              {quantity}
            </span>
            <button
              type="button"
              onClick={() => setQuantity(Math.min(product.stock || 99, quantity + 1))}
              disabled={isOutOfStock || quantity >= (product.stock || 99)}
              className="w-9 h-9 rounded-lg flex items-center justify-center font-black text-base text-slate-600 hover:bg-slate-100 disabled:opacity-30 transition-colors cursor-pointer border-none bg-transparent"
              aria-label="Augmenter la quantité"
            >
              +
            </button>
          </div>
        </div>

        {/* Stock Status Pill */}
        <div>
          {!isOutOfStock && product.stock > 5 ? (
            <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200/70">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              {isAr ? "متوفر في المخزون" : "En stock immédiat"}
            </span>
          ) : !isOutOfStock && product.stock > 0 ? (
            <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200/70">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              {isAr ? `بقي ${product.stock} فقط` : `Plus que ${product.stock} en stock`}
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-rose-700 bg-rose-50 px-3 py-1 rounded-full border border-rose-200/70">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              {isAr ? "نفدت الكمية" : "Rupture de stock"}
            </span>
          )}
        </div>
      </div>

      {/* Primary Action Buttons */}
      <div className="flex items-center gap-2.5">
        <button
          type="button"
          disabled={isOutOfStock}
          onClick={() => onAddToCart(quantity)}
          className={`flex-1 h-13 px-6 rounded-2xl font-black text-sm tracking-wide transition-all flex items-center justify-center gap-2.5 cursor-pointer border-none ${
            !isOutOfStock
              ? "bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 text-white active:scale-[0.99] shadow-lg shadow-orange-500/25"
              : "bg-slate-100 text-slate-400 cursor-not-allowed"
          }`}
        >
          <ShoppingBag className="w-5 h-5 stroke-[2.2]" />
          <span>
            {!isOutOfStock
              ? tr("add_to_cart", "Ajouter au panier", "أضف إلى السلة")
              : tr("product.details.unavailable", "Indisponible", "غير متوفر")}
          </span>
        </button>

        {/* Wishlist Button */}
        <button
          type="button"
          onClick={onToggleWishlist}
          aria-label={isLiked ? "Retirer des favoris" : "Ajouter aux favoris"}
          className={`w-13 h-13 rounded-2xl border flex items-center justify-center transition-all shrink-0 cursor-pointer ${
            isLiked
              ? "bg-rose-50 border-rose-200 text-rose-600 shadow-2xs"
              : "bg-white border-slate-200 text-slate-600 hover:border-orange-300 hover:text-orange-600"
          }`}
        >
          <Heart className={`w-5 h-5 ${isLiked ? "fill-rose-600" : ""}`} />
        </button>

        {/* Share Button */}
        <button
          type="button"
          onClick={onShare}
          aria-label="Partager ce produit"
          className="w-13 h-13 rounded-2xl border border-slate-200 bg-white text-slate-600 hover:border-orange-300 hover:text-orange-600 flex items-center justify-center transition-all shrink-0 cursor-pointer"
        >
          <Share2 className="w-5 h-5" />
        </button>
      </div>

      {/* 4 Reassurance Pillars */}
      <div className="grid grid-cols-2 gap-2.5 pt-2">
        <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-50/80 border border-slate-200/70">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <Banknote className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-slate-800 leading-tight">
            {isAr ? "الدفع عند الاستلام" : "Paiement à la livraison"}
          </span>
        </div>
        <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-50/80 border border-slate-200/70">
          <div className="w-8 h-8 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center shrink-0">
            <Truck className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-slate-800 leading-tight">
            {isAr ? "توصيل 58 ولاية" : "Livraison 58 Wilayas"}
          </span>
        </div>
        <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-50/80 border border-slate-200/70">
          <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <RotateCcw className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-slate-800 leading-tight">
            {isAr ? "إرجاع مضمون" : "Retours faciles"}
          </span>
        </div>
        <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-50/80 border border-slate-200/70">
          <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-slate-800 leading-tight">
            {isAr ? "ضمان أولمارت" : "Protection Acheteur"}
          </span>
        </div>
      </div>

      {/* Sticky Mobile Bottom Buy Bar */}
      {isSticky && (
        <div className="fixed bottom-16 lg:bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-xl border-t border-slate-200/90 px-4 py-3 shadow-[0_-8px_24px_rgba(15,23,42,0.08)] flex items-center justify-between gap-4 sm:hidden">
          <div className="min-w-0">
            <p className="text-[11px] font-bold text-slate-400 truncate">
              {product.name}
            </p>
            <p className="text-base font-black text-slate-900 tabular-nums">
              {formatPrice(effectivePrice)}
            </p>
          </div>
          <button
            type="button"
            disabled={isOutOfStock}
            onClick={() => onAddToCart(quantity)}
            className={`h-11 px-5 rounded-xl font-black text-xs tracking-wide transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer border-none ${
              !isOutOfStock
                ? "bg-gradient-to-r from-orange-500 to-rose-600 text-white shadow-md shadow-orange-500/25 active:scale-95"
                : "bg-slate-100 text-slate-400 cursor-not-allowed"
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>
              {!isOutOfStock
                ? tr("add_to_cart", "Ajouter au panier", "أضف إلى السلة")
                : tr("product.details.unavailable", "Indisponible", "غير متوفر")}
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
