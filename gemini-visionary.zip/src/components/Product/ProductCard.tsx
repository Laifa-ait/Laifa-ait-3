import React from "react";
import { Heart, Scale, Star, ArrowUpRight } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import { useComparatorStore } from "../../store/useComparatorStore";
import { Product } from "../../domains/product/product.types";
import { formatPrice } from "../../utils/format";
import { getTranslatedField } from "../../utils/translations";
import { getOptimizedImageUrl } from "../../utils/imageUtils";

const getEnergyColor = (cls?: string) => {
  switch (cls) {
    case "A": return "#009640";
    case "B": return "#50B848";
    case "C": return "#C2D82E";
    case "D": return "#FFED00";
    case "E": return "#FBBA15";
    case "F": return "#EC6608";
    case "G": return "#E30613";
    default: return "#10B981";
  }
};

interface ProductCardProps {
  product: Product;
  index?: number;
  onClick?: (product: Product) => void;
  isFeatured?: boolean;
  variant?: "default" | "premium_immersive" | "flash_sale";
  sectionStyle?: string;
  styleVariant?: "clean" | "premium" | "immersive" | "glass" | "dark" | string;
  isFlashSale?: boolean;
}

export const ProductCard = React.memo(
  ({
    product,
    index: _index,
    onClick,
    isFeatured: _isFeatured = false,
    variant = "default",
    sectionStyle,
    styleVariant = "clean",
    isFlashSale: isFlashSaleProp,
  }: ProductCardProps) => {
    const { t, i18n } = useTranslation();
    const { wishlist, toggleWishlist } = useCart();
    const navigate = useNavigate();
    const lang = i18n.language;
    const isProductFlashActive = isFlashSaleProp || false;

    const {
      products: comparedProducts,
      addProduct: addToCompare,
      removeProduct: removeFromCompare,
    } = useComparatorStore();
    const isCompared = comparedProducts.some((p) => p.id === product.id);

    const defaultClick = (prod: Product) => {
      if (onClick) onClick(prod);
      else navigate(`/product/${prod.id}`);
    };

    const currentPrice = isProductFlashActive
      ? product.flashPrice || 0
      : product.promoPrice || product.price || 0;

    const hasDiscount =
      (product.promoPrice && product.promoPrice < (product.price || 0)) ||
      (isProductFlashActive && product.flashPrice && product.flashPrice < (product.price || 0)) ||
      (product.originalPrice && product.originalPrice > currentPrice);

    const originalPrice = product.originalPrice || product.price || 0;
    const discountPercent =
      hasDiscount && originalPrice > 0
        ? Math.round(((originalPrice - currentPrice) / originalPrice) * 100)
        : 0;

    const isPremium = variant === "premium_immersive" || styleVariant === "premium";
    const isImmersive = styleVariant === "immersive";
    const isGlass = styleVariant === "glass";
    const isDark = styleVariant === "dark";

    const getContainerStyles = () => {
      if (isGlass) {
        return "bg-white/95 backdrop-blur-md border border-slate-200/90 shadow-sm hover:shadow-xl";
      }
      if (isPremium) {
        return "bg-white border-2 border-orange-500/80 shadow-md hover:shadow-xl hover:-translate-y-1";
      }
      if (isImmersive) {
        return "bg-white border-2 border-slate-900 shadow-md hover:shadow-xl hover:-translate-y-1";
      }
      if (isDark) {
        return "bg-slate-900 border border-slate-800 text-white";
      }
      return "bg-white border border-slate-200/80 hover:border-orange-300 shadow-[0_2px_10px_rgba(15,23,42,0.04)] hover:shadow-[0_14px_30px_rgba(15,23,42,0.1)] hover:-translate-y-1";
    };

    return (
      <div
        className={`group flex flex-col overflow-hidden rounded-2xl sm:rounded-3xl transition-all duration-300 cursor-pointer h-full relative ${getContainerStyles()} ${sectionStyle || ""}`}
        onClick={() => defaultClick(product)}
      >
        {/* Crisp Square Image Container */}
        <div className="relative aspect-square w-full overflow-hidden bg-slate-100/80">
          <img
            src={getOptimizedImageUrl(product.image, 600) || "/images/placeholders/product.svg"}
            alt={getTranslatedField(product, "name", lang)}
            loading="lazy"
            decoding="async"
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-106"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = "/images/placeholders/product.svg";
            }}
          />

          {/* Top-Left Vivid Badges */}
          <div className="absolute top-2.5 start-2.5 z-20 flex flex-col items-start gap-1.5 pointer-events-none">
            {hasDiscount && discountPercent > 0 && (
              <span className="inline-flex items-center bg-gradient-to-r from-rose-600 to-orange-500 text-white font-sans font-black text-[10px] sm:text-[11px] px-2.5 py-0.5 rounded-full shadow-sm">
                -{discountPercent}%
              </span>
            )}
            {product.isSponsored && (
              <span className="bg-slate-950/80 backdrop-blur-md text-amber-300 font-sans font-bold text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full">
                {t("Sponsorisé")}
              </span>
            )}
            {product.energyClass && (
              <span
                className="text-white font-sans font-extrabold text-[9px] px-1.5 py-0.5 rounded shadow-xs"
                style={{ backgroundColor: getEnergyColor(product.energyClass) }}
              >
                {product.energyClass}
              </span>
            )}
          </div>

          {/* Top-Right Quick Actions */}
          <div className="absolute top-2.5 end-2.5 z-20 flex flex-col gap-1.5">
            <button
              type="button"
              aria-label={wishlist.includes(product.id) ? "Retirer des favoris" : "Ajouter aux favoris"}
              onClick={(e) => {
                e.stopPropagation();
                toggleWishlist(product.id);
              }}
              className="w-8 h-8 rounded-full bg-white/95 hover:bg-white backdrop-blur-md flex items-center justify-center text-slate-700 hover:text-rose-600 hover:scale-110 active:scale-95 transition-all shadow-sm cursor-pointer border border-slate-200/70"
            >
              <Heart
                className={`w-3.5 h-3.5 ${
                  wishlist.includes(product.id) ? "fill-rose-500 text-rose-500" : "stroke-[2.2]"
                }`}
              />
            </button>
            <button
              type="button"
              aria-label={isCompared ? "Retirer du comparateur" : "Ajouter au comparateur"}
              onClick={(e) => {
                e.stopPropagation();
                if (isCompared) removeFromCompare(product.id);
                else addToCompare(product);
              }}
              className={`w-8 h-8 rounded-full backdrop-blur-md flex items-center justify-center shadow-sm hover:scale-110 active:scale-95 transition-all cursor-pointer border ${
                isCompared
                  ? "bg-orange-500 text-white border-transparent"
                  : "bg-white/95 text-slate-700 hover:text-orange-600 border-slate-200/70 opacity-0 group-hover:opacity-100"
              }`}
            >
              <Scale className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-3 sm:p-4 flex flex-col flex-1 justify-between gap-2.5 bg-white">
          <div className="space-y-1">
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-orange-600 truncate">
                {product.category || product.sellerName || "Olmart"}
              </span>
              {Number(product.rating || 0) > 0 && (
                <div className="inline-flex items-center gap-0.5 bg-amber-50 text-amber-800 px-1.5 py-0.5 rounded-md text-[10px] font-extrabold shrink-0 border border-amber-200/60">
                  <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                  <span>{Number(product.rating).toFixed(1)}</span>
                </div>
              )}
            </div>

            <h3 className="font-sans font-bold text-slate-900 group-hover:text-orange-600 text-[13px] sm:text-sm leading-snug line-clamp-2 transition-colors">
              {getTranslatedField(product, "name", lang)}
            </h3>
          </div>

          {/* Price & Action Footer */}
          <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2 mt-auto">
            <div className="flex flex-col">
              <span className="font-sans font-black text-sm sm:text-base tracking-tight tabular-nums text-slate-950">
                {formatPrice(currentPrice)}
              </span>
              {hasDiscount && (
                <span className="font-sans text-[11px] text-slate-400 line-through tabular-nums leading-none mt-0.5">
                  {formatPrice(originalPrice)}
                </span>
              )}
            </div>

            <div className="w-8 h-8 rounded-xl bg-orange-50 group-hover:bg-gradient-to-r group-hover:from-orange-500 group-hover:to-rose-600 text-orange-600 group-hover:text-white flex items-center justify-center shrink-0 transition-all shadow-2xs">
              <ArrowUpRight className="w-4 h-4 stroke-[2.4]" />
            </div>
          </div>
        </div>
      </div>
    );
  }
);
